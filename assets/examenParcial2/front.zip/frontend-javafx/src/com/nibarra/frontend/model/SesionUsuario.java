package com.nibarra.frontend.model;

public class SesionUsuario {
    private String usuario;
    private String evento;
    private String fecha;

    public SesionUsuario(String usuario, String evento, String fecha) {
        this.usuario = usuario;
        this.evento = evento;
        this.fecha = fecha;
    }

    public String getUsuario() { return usuario; }
    public String getEvento() { return evento; }
    public String getFecha() { return fecha; }
}
