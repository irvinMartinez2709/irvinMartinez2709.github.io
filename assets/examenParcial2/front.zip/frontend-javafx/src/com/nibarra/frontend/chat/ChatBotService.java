package com.nibarra.frontend.chat;

import com.nibarra.frontend.chat.IntentRouter.Intent;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public class ChatBotService {

    // Inyecta tus repositorios reales aquí
    private final UsuariosRepository usuariosRepo;
    private final TecnicosRepository tecnicosRepo;
    private final MantenimientosRepository mantsRepo;

    public ChatBotService(UsuariosRepository u, TecnicosRepository t, MantenimientosRepository m) {
        this.usuariosRepo = u;
        this.tecnicosRepo = t;
        this.mantsRepo = m;
    }

    public String answer(Intent intent, String userText) {
        switch (intent) {
            case SALUDO:
                return "Hola. Puedo listar usuarios, técnicos, mostrar el próximo mantenimiento, el estado de un folio, pendientes y horarios de un técnico. Pide “ayuda” para ver ejemplos.";

            case AYUDA:
                return """
                       Ejemplos:
                       • “¿Próximo mantenimiento?” 
                       • “Estado del folio-82”
                       • “¿Cuántos pendientes hay?”
                       • “Horario del técnico Luis”
                       • “Lista de usuarios”
                       • “Lista de técnicos”
                       """;

            case LISTAR_USUARIOS: {
                List<String> usuarios = usuariosRepo.listarNombresActivos();
                if (usuarios.isEmpty()) return "No hay usuarios activos registrados.";
                return "Usuarios activos: " + String.join(", ", usuarios);
            }

            case LISTAR_TECNICOS: {
                List<String> tecnicos = tecnicosRepo.listarNombres();
                if (tecnicos.isEmpty()) return "No hay técnicos registrados.";
                return "Técnicos: " + String.join(", ", tecnicos);
            }

            case PROXIMO_MANTENIMIENTO: {
                Optional<MantenimientoDTO> prox = mantsRepo.buscarProximoDesde(LocalDate.now());
                return prox.map(m -> String.format("Próximo mantenimiento: folio %s, equipo %s, tipo %s, programado para %s.",
                        m.folio(), m.equipo(), m.tipo(), m.fechaProgramada()))
                        .orElse("No hay mantenimientos programados próximos.");
            }

            case ESTADO_FOLIO: {
                Integer folio = extraerFolio(userText);
                if (folio == null) return "Indícame el folio, por ejemplo: “Estado del folio-82”.";
                return mantsRepo.buscarPorFolio(folio)
                        .map(m -> String.format("Folio %d está en estado %s, avance %d%%, fecha %s.",
                                folio, m.estado(), m.avance(), m.fechaProgramada()))
                        .orElse("No encontré ese folio.");
            }

            case PENDIENTES: {
                long count = mantsRepo.contarPorEstado("POR_HACER");
                return "Pendientes por hacer: " + count + ".";
            }

            case HORARIO_TECNICO: {
                String nombre = extraerNombreTecnico(userText);
                if (nombre == null || nombre.isBlank())
                    return "Dime el nombre del técnico. Ejemplo: “Horario del técnico Luis”.";
                return tecnicosRepo.horarioDe(nombre)
                        .map(h -> "Horario de " + nombre + ": " + h)
                        .orElse("No encontré el técnico " + nombre + ".");
            }

            default:
                return "No entendí la solicitud. Escribe “ayuda” para ver ejemplos.";
        }
    }

    private Integer extraerFolio(String text) {
        if (text == null) return null;
        var m = java.util.regex.Pattern.compile("folio\\s*[-#: ]?(\\d+)").matcher(text.toLowerCase());
        if (m.find()) return Integer.parseInt(m.group(1));
        return null;
    }

    private String extraerNombreTecnico(String text) {
        if (text == null) return null;
        // Ingenuo pero práctico: toma la palabra después de “técnico”
        var m = java.util.regex.Pattern.compile("t[eé]cnico\\s+([\\p{L}]+)", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(text);
        if (m.find()) return capitalize(m.group(1));
        return null;
    }

    private String capitalize(String s) {
        if (s.length() == 0) return s;
        return s.substring(0,1).toUpperCase() + s.substring(1).toLowerCase();
    }

    // Interfaces mínimas para acoplar a tus DAOs reales
    public interface UsuariosRepository { List<String> listarNombresActivos(); }
    public interface TecnicosRepository {
        List<String> listarNombres();
        Optional<String> horarioDe(String nombre);
    }
    public interface MantenimientosRepository {
        Optional<MantenimientoDTO> buscarProximoDesde(LocalDate desde);
        Optional<MantenimientoDTO> buscarPorFolio(int folio);
        long contarPorEstado(String estado);
    }
    public record MantenimientoDTO(int folio, String equipo, String tipo, String estado, int avance, LocalDate fechaProgramada) {}
}
