package com.nibarra.frontend.controller;

import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import com.nibarra.frontend.model.Equipo;
import com.nibarra.frontend.model.EventoCalendario;
import com.nibarra.frontend.service.EquipoDAO;
import com.nibarra.frontend.model.Mantenimiento;
import com.nibarra.frontend.controller.UsuariosController;
import com.nibarra.frontend.model.Usuario;
import com.nibarra.frontend.service.CalendarioDAO;
import com.nibarra.frontend.service.MantenimientoDAO;
import java.io.IOException;
import com.nibarra.frontend.util.UsuarioSesion;
import java.time.LocalDate;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import com.nibarra.frontend.App;
import com.nibarra.frontend.model.EquipoIntegrante;
import com.nibarra.frontend.service.EquipoIntegranteDAO;

// Chatbot import
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.scene.control.Tab;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javax.swing.JOptionPane;

public class DashboardController {

    // Menú lateral 
    @FXML
    private Label lblTituloMenu;
    @FXML
    private Button btnEquipos;
    @FXML
    private Button btnMantenimientos;
    @FXML
    private Button btnCalendario;
    @FXML
    private Button btnChatbot;
    @FXML
    private Button btnEstadisticas;
    @FXML
    private Button btnCerrarSesion;

    //  Main
    @FXML
    private AnchorPane mainContent;
    @FXML
    private TabPane tabPanePrincipal;

    // EQUIPOS 
    @FXML
    private ComboBox<String> cbFamilia;
    @FXML
    private TableColumn<Equipo, String> colFamilia;
    @FXML
    private TableColumn<Equipo, String> colTipoDetallado;
    @FXML
    private TableColumn<Equipo, String> colProvincia;
    @FXML
    private TableColumn<Equipo, String> colDireccion;
    @FXML
    private TableColumn<Equipo, String> colHorarioBase;
    @FXML
    private TextField txtHorarioBase;

    @FXML
    private Label lblTituloEquipos;
    @FXML
    private javafx.scene.control.TextField txtIdEquipo;
    @FXML
    private javafx.scene.control.TextField txtCodigo;
    @FXML
    private javafx.scene.control.TextField txtTipo;
    @FXML
    private javafx.scene.control.TextField txtUbicacion;
    @FXML
    private ComboBox<String> cbEstado;
    @FXML
    private TableView<Equipo> tblEquipos;
    @FXML
    private TableColumn<Equipo, Number> colId;
    @FXML
    private TableColumn<Equipo, String> colCodigo;
    @FXML
    private TableColumn<Equipo, String> colTipo;
    @FXML
    private TableColumn<Equipo, String> colUbicacion;
    @FXML
    private TableColumn<Equipo, String> colEstado;
    @FXML
    private Button btnNuevoEquipo;
    @FXML
    private Button btnGuardarEquipo;
    @FXML
    private Button btnActualizarEquipo;
    @FXML
    private Button btnEliminarEquipo;
    @FXML
    private TableColumn<Equipo, String> colUsuarioRegistro;
    @FXML
    private TableColumn<Equipo, String> colDisponible;

    @FXML
    private javafx.scene.control.TextField txtTipoDetallado;
    @FXML
    private javafx.scene.control.TextField txtHorarioDefault;

    @FXML
    private javafx.scene.control.TextField txtProvincia;
    @FXML
    private javafx.scene.control.TextField txtDireccion;

    private final EquipoDAO equipoDAO = new EquipoDAO();
    private final ObservableList<Equipo> dataEquipos = FXCollections.observableArrayList();

    //  MANTENIMIENTOS 
    @FXML
    private javafx.scene.layout.AnchorPane rootMantenimientos;
    @FXML
    private javafx.scene.control.TableView<com.nibarra.frontend.model.Mantenimiento> tblMantenimientos;
    @FXML
    private javafx.scene.control.TableColumn<com.nibarra.frontend.model.Mantenimiento, String> colFolio;
    @FXML
    private javafx.scene.control.TableColumn<com.nibarra.frontend.model.Mantenimiento, String> colEquipo;
    @FXML
    private javafx.scene.control.TableColumn<com.nibarra.frontend.model.Mantenimiento, String> colTipoMant;
    @FXML
    private javafx.scene.control.TableColumn<com.nibarra.frontend.model.Mantenimiento, String> colEstadoMant;
    @FXML
    private javafx.scene.control.TableColumn<com.nibarra.frontend.model.Mantenimiento, Number> colAvance;
    @FXML
    private javafx.scene.control.TableColumn<com.nibarra.frontend.model.Mantenimiento, String> colFechaProg;

    @FXML
    private javafx.scene.control.TextField txtFolio;
    @FXML
    private javafx.scene.control.TextField txtEquipo;
    @FXML
    private javafx.scene.control.ComboBox<String> cbTipoMant;
    @FXML
    private javafx.scene.control.ComboBox<String> cbEstadoMant;
    @FXML
    private javafx.scene.control.DatePicker dpFechaProg;
    @FXML
    private javafx.scene.control.TextArea txtDescripcion;
    @FXML
    private javafx.scene.control.ProgressBar pbAvance;
    @FXML
    private javafx.scene.control.Slider sldAvance;
    @FXML
    private ComboBox<String> cbFiltroTipo;
    @FXML
    private ComboBox<String> cbFiltroEstado;
    @FXML
    private javafx.scene.control.DatePicker dpDesde;
    @FXML
    private javafx.scene.control.DatePicker dpHasta;
    private final com.nibarra.frontend.service.MantenimientoDAO mantDAO = new com.nibarra.frontend.service.MantenimientoDAO();
    private final javafx.collections.ObservableList<com.nibarra.frontend.model.Mantenimiento> dataMants
            = javafx.collections.FXCollections.observableArrayList();

//  BACKEND CHATBOT
    private static final String CHAT_BASE_URL = "http://localhost:8081";
    private final HttpClient http = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(5))
            .build();

    //MÓDULO CALENDARIO 
    @FXML
    private AnchorPane rootCalendario;
    @FXML
    private Label lblTituloCalendario;
    @FXML
    private javafx.scene.control.DatePicker dpFechaBase;
    @FXML
    private ComboBox<String> cbMes;
    @FXML
    private ComboBox<String> cbAnio;
    @FXML
    private Button btnHoy;
    @FXML
    private Button btnRefrescarCal;
    @FXML
    private Button btnAgregarEvento;
    @FXML
    private AnchorPane paneCalendarioMes;
    @FXML
    private AnchorPane paneEventosDia;
    @FXML
    private Label lblEventosDia;
    @FXML
    private javafx.scene.control.TableView<com.nibarra.frontend.model.EventoCalendario> tblEventosDia;
    @FXML
    private javafx.scene.control.TableColumn<com.nibarra.frontend.model.EventoCalendario, String> colFolioEvento;
    @FXML
    private javafx.scene.control.TableColumn<com.nibarra.frontend.model.EventoCalendario, String> colTipoEvento;
    @FXML
    private javafx.scene.control.TableColumn<com.nibarra.frontend.model.EventoCalendario, String> colEstadoEvento;
    @FXML
    private Button btnVerDetalleEvento;
    @FXML
    private Button btnEditarEvento;
    @FXML
    private Button btnEliminarEvento;
    @FXML
    private javafx.scene.layout.GridPane gridCalendario;
    private final com.nibarra.frontend.service.CalendarioDAO calendarioDAO = new com.nibarra.frontend.service.CalendarioDAO();
    private final javafx.collections.ObservableList<com.nibarra.frontend.model.EventoCalendario> eventosDia
            = javafx.collections.FXCollections.observableArrayList();
    // HISTORIALS

    @FXML
    private javafx.scene.control.TextField txtUsuario;

    @FXML
    private javafx.scene.control.PasswordField txtContrasena;

    @FXML
    private javafx.scene.control.Button btnLimpiarLogin;

    @FXML
    private TableView<com.nibarra.frontend.model.SesionUsuario> tblHistorial;
    @FXML
    private TableColumn<com.nibarra.frontend.model.SesionUsuario, String> colUsuario;
    @FXML
    private TableColumn<com.nibarra.frontend.model.SesionUsuario, String> colEvento;
    @FXML
    private TableColumn<com.nibarra.frontend.model.SesionUsuario, String> colFecha;

    private final ObservableList<com.nibarra.frontend.model.SesionUsuario> dataHistorial
            = FXCollections.observableArrayList();

    // CHATBOT
    @FXML
    private javafx.scene.layout.HBox boxTopChat;
    @FXML
    private javafx.scene.control.Label lblTituloChat;
    @FXML
    private javafx.scene.control.Button btnLimpiarChat;
    @FXML
    private javafx.scene.control.Button btnExportarChat;
    @FXML
    private javafx.scene.layout.HBox boxSugerencias;
    @FXML
    private javafx.scene.control.Button btnSugProximoMant;
    @FXML
    private javafx.scene.control.Button btnSugEstadoFolio;
    @FXML
    private javafx.scene.control.Button btnSugPendientes;
    @FXML
    private javafx.scene.control.Button btnSugHorario;
    @FXML
    private javafx.scene.control.ScrollPane scrollChat;
    @FXML
    private javafx.scene.layout.VBox boxMensajes;
    @FXML
    private javafx.scene.layout.HBox boxInputChat;
    @FXML
    private javafx.scene.control.TextField txtMensaje;

    @FXML
    private javafx.scene.control.Button btnEnviar;
    @FXML
    private javafx.scene.control.Button btnSugerencias;
    @FXML
    private javafx.scene.layout.BorderPane rootChatbot;

    // MÓDULO ESTADÍSTICAS 
    @FXML
    private AnchorPane rootEstadisticas;
    @FXML
    private javafx.scene.control.Label lblTituloEstadisticas;
    @FXML
    private javafx.scene.layout.HBox boxFiltrosEstadisticas;
    @FXML
    private javafx.scene.control.DatePicker dpDesdeEst;
    @FXML
    private javafx.scene.control.DatePicker dpHastaEst;
    @FXML
    private ComboBox<String> cbTipoGrafico;
    @FXML
    private javafx.scene.control.Button btnActualizarEst;
    @FXML
    private javafx.scene.control.Button btnExportarEst;
    @FXML
    private javafx.scene.layout.VBox boxGraficos;
    @FXML
    private javafx.scene.control.TitledPane tpAvanceGlobal;
    @FXML
    private javafx.scene.control.TitledPane tpMantenimientosTipo;
    @FXML
    private javafx.scene.control.TitledPane tpUsoChatbot;
    @FXML
    private AnchorPane paneAvanceGlobal;
    @FXML
    private javafx.scene.control.ProgressBar pbAvanceGlobal;
    @FXML
    private javafx.scene.control.Label lblPorcentajeAvance;
    @FXML
    private AnchorPane paneMantenimientosTipo;
    @FXML
    private javafx.scene.chart.PieChart chartTipoMant;
    @FXML
    private javafx.scene.layout.VBox boxResumenTipo;
    @FXML
    private javafx.scene.control.Label lblPredictivo;
    @FXML
    private javafx.scene.control.Label lblPreventivo;
    @FXML
    private javafx.scene.control.Label lblCorrectivo;
    @FXML
    private AnchorPane paneUsoChatbot;
    @FXML
    private javafx.scene.chart.BarChart<String, Number> chartUsoChatbot;
    @FXML
    private javafx.scene.layout.VBox boxResumenChatbot;
    @FXML
    private javafx.scene.control.Label lblMensajesTotales;
    @FXML
    private javafx.scene.control.Label lblPreguntas;
    @FXML
    private javafx.scene.control.Label lblRespuestas;
    private final com.nibarra.frontend.service.EstadisticasDAO estDAO = new com.nibarra.frontend.service.EstadisticasDAO();
    // NUEVOS TABS
    @FXML
    private Tab tabUsuarios;
    @FXML
    private Tab tabEquiposReparacion;

// Motor
    private com.nibarra.frontend.chat.IntentRouter intentRouter;
    private com.nibarra.frontend.chat.ChatBotService chatService;

    // Inicialización 
    @FXML
    private void initialize() {
        System.out.println(getClass().getResource("/com/nibarra/frontend/view/UsuariosView.fxml"));

        try {

            if (dpDesde != null) {
                dpDesde.setConverter(new javafx.util.StringConverter<>() {
                    private final java.time.format.DateTimeFormatter fmt = java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd");

                    @Override
                    public String toString(LocalDate date) {
                        return (date != null) ? fmt.format(date) : "";
                    }

                    @Override
                    public LocalDate fromString(String s) {
                        return (s != null && !s.isEmpty()) ? LocalDate.parse(s, fmt) : null;
                    }
                });
            }
            AnchorPane usuariosPane = FXMLLoader.load(getClass().getResource("/com/nibarra/frontend/view/UsuariosView.fxml"));
            tabUsuarios.setContent(usuariosPane);

            AnchorPane reparacionPane = FXMLLoader.load(getClass().getResource("/com/nibarra/frontend/view/EquiposReparacionView.fxml"));
            tabEquiposReparacion.setContent(reparacionPane);

            if (dpHasta != null) {
                dpHasta.setConverter(new javafx.util.StringConverter<>() {
                    private final java.time.format.DateTimeFormatter fmt = java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd");

                    @Override
                    public String toString(LocalDate date) {
                        return (date != null) ? fmt.format(date) : "";
                    }

                    @Override
                    public LocalDate fromString(String s) {
                        return (s != null && !s.isEmpty()) ? LocalDate.parse(s, fmt) : null;
                    }
                });
            }

            tblEquipos.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, sel) -> {
                if (sel == null) {
                    return;
                }

                if (txtIdEquipo != null) {
                    txtIdEquipo.setText(String.valueOf(sel.getId()));
                }

                if (txtCodigo != null) {
                    txtCodigo.setText(sel.getCodigo());
                }
                if (txtTipo != null) {
                    txtTipo.setText(sel.getTipo());
                }
                if (cbFamilia != null) {
                    cbFamilia.setValue(sel.getFamilia());
                }
                if (txtTipoDetallado != null) {
                    txtTipoDetallado.setText(sel.getTipoDetallado());
                }
                if (txtUbicacion != null) {
                    txtUbicacion.setText(sel.getUbicacion());
                }
                if (txtProvincia != null) {
                    txtProvincia.setText(sel.getProvincia());
                }
                if (txtDireccion != null) {
                    txtDireccion.setText(sel.getDireccion());
                }
                if (txtHorarioBase != null) {
                    txtHorarioBase.setText(sel.getHorarioBase());
                }
                if (cbEstado != null) {
                    cbEstado.setValue(sel.getEstado());
                }

                System.out.println(":) Equipo seleccionado: ID=" + sel.getId() + ", Código=" + sel.getCodigo());
            });
            cbFamilia.getItems().addAll(
                    "Aire Acondicionado",
                    "Refrigeración",
                    "Energía y Bombeo",
                    "Lavandería",
                    "Energía Renovable",
                    "Redes y Comunicación"
            );
            colFamilia.setCellValueFactory(new PropertyValueFactory<>("familia"));
            colTipoDetallado.setCellValueFactory(new PropertyValueFactory<>("tipoDetallado"));
            colProvincia.setCellValueFactory(new PropertyValueFactory<>("provincia"));
            colDireccion.setCellValueFactory(new PropertyValueFactory<>("direccion"));
            colHorarioBase.setCellValueFactory(new PropertyValueFactory<>("horarioBase"));

            if (tabPanePrincipal != null) {
                tabPanePrincipal.getSelectionModel().selectedItemProperty().addListener((obs, oldTab, newTab) -> {
                    if (newTab != null && "Historial de sesiones".equals(newTab.getText())) {
                        cargarHistorialSesiones();
                    }
                });
            }

            colId.setCellValueFactory(new PropertyValueFactory<>("id"));
            if (colCodigo != null) {
                colCodigo.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getCodigo()));
            }
            if (colTipo != null) {
                colTipo.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getTipo()));
            }
            if (colUbicacion != null) {
                colUbicacion.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getUbicacion()));
            }
            if (colEstado != null) {
                colEstado.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getEstado()));
            }
            if (colUsuarioRegistro != null) {
                colUsuarioRegistro.setCellValueFactory(c
                        -> new javafx.beans.property.SimpleStringProperty(c.getValue().getUsuarioRegistro()));
            }
            colDisponible.setCellValueFactory(c
                    -> new SimpleStringProperty(c.getValue().isDisponible() ? "Sí" : "No")
            );

            if (tblEquipos != null) {
                tblEquipos.setItems(dataEquipos);
                // Listener de selección

            }

            if (cbEstado != null) {
                cbEstado.getItems().setAll("Activo", "Inactivo", "En reparación");
            }

            // Cargar datos
            cargarEquiposDesdeDAO();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        cargarHistorialSesiones();

        //Mantenimientos
        if (cbTipoMant != null) {
            cbTipoMant.getItems().setAll("Predictivo", "Preventivo", "Correctivo");
        }

        if (cbEstadoMant != null) {
            cbEstadoMant.getItems().setAll("Por hacer", "En espera de material", "En revisión", "Terminada");
        }

        if (cbFiltroTipo != null) {
            cbFiltroTipo.getItems().setAll("Todos", "Predictivo", "Preventivo", "Correctivo");
            cbFiltroTipo.setValue("Todos");
            cbFiltroTipo.valueProperty().addListener((obs, oldV, newV) -> {

                try {
                    filtrarMantenimientos(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
        }

        if (cbFiltroEstado != null) {
            cbFiltroEstado.getItems().setAll("Todos", "Por hacer", "En espera de material", "En revisión", "Terminada");
            cbFiltroEstado.setValue("Todos");
            cbFiltroEstado.valueProperty().addListener((obs, oldV, newV) -> {

                try {
                    filtrarMantenimientos(null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
        }

        if (pbAvance != null) {
            pbAvance.setProgress(0);
        }
        if (sldAvance != null) {
            sldAvance.setValue(0);
        }
        if (sldAvance != null && pbAvance != null) {
            sldAvance.valueProperty().addListener((obs, oldV, newV)
                    -> pbAvance.setProgress(newV.doubleValue() / 100.0)
            );
        }

        if (tblMantenimientos != null) {
            colFolio.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getFolio()));
            colEquipo.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getEquipo()));
            colTipoMant.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getTipoMant()));
            colEstadoMant.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getEstado()));
            colAvance.setCellValueFactory(c -> new javafx.beans.property.SimpleIntegerProperty(c.getValue().getAvance()));
            colFechaProg.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(
                    c.getValue().getFechaProgramada().toString()
            ));
            tblMantenimientos.setItems(dataMants);

            tblMantenimientos.getSelectionModel().selectedItemProperty().addListener((obs, old, sel) -> {
                if (sel != null) {
                    txtFolio.setText(sel.getFolio());
                    txtEquipo.setText(sel.getEquipo());
                    cbTipoMant.setValue(sel.getTipoMant());
                    cbEstadoMant.setValue(sel.getEstado());
                    dpFechaProg.setValue(sel.getFechaProgramada());
                    txtDescripcion.setText(sel.getDescripcion());
                    pbAvance.setProgress(sel.getAvance() / 100.0);
                    sldAvance.setValue(sel.getAvance());
                }
            });
        }

        cargarMantenimientos();

        //  Chatbot 
        if (boxSugerencias != null) {
            boxSugerencias.setVisible(true);
        }
        scrollChat.viewportBoundsProperty().addListener((obs, old, newVal) -> {
            for (Node n : boxMensajes.getChildren()) {
                if (n instanceof HBox fila) {
                    for (Node c : fila.getChildren()) {
                        if (c instanceof Label lbl) {
                            lbl.setMaxWidth(newVal.getWidth() * 0.8);
                        }
                    }
                }
            }
        });

        // Estadísticas
        if (cbTipoGrafico != null) {
            cbTipoGrafico.getItems().setAll("Todos", "Avance global", "Mantenimientos por tipo", "Uso ChatBot");
        }
        if (pbAvanceGlobal != null) {
            pbAvanceGlobal.setProgress(0.65);
        }
        if (lblPorcentajeAvance != null) {
            lblPorcentajeAvance.setText("65 % completado");
        }

        // Calendario
        if (cbMes != null) {
            cbMes.getItems().setAll("Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
                    "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre");
        }
        if (cbMes != null) {
            cbMes.getSelectionModel().select(LocalDate.now().getMonthValue() - 1);
        }

        if (cbAnio != null) {
            int anioActual = java.time.LocalDate.now().getYear();
            for (int i = anioActual - 2; i <= anioActual + 2; i++) {
                cbAnio.getItems().add(String.valueOf(i));
            }
            cbAnio.setValue(String.valueOf(anioActual));
        }
        if (cbMes != null) {
            cbMes.setOnAction(e -> refrescarCalendario());
        }
        if (cbAnio != null) {
            cbAnio.setOnAction(e -> refrescarCalendario());
        }

        if (dpFechaBase != null) {
            dpFechaBase.setValue(java.time.LocalDate.now());
        }

        if (tblEventosDia != null) {
            colFolioEvento.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getFolio()));
            colTipoEvento.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getTipo()));
            colEstadoEvento.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getEstado()));
            tblEventosDia.setItems(eventosDia);
        }

        if (gridCalendario != null) {
            dibujarCalendario(LocalDate.now());
        }

        boxMensajes.widthProperty().addListener((obs, oldW, newW) -> {
            boxMensajes.setPrefWidth(scrollChat.getViewportBounds().getWidth());
        });

        //  BURBUJA FLOTANTE DEL CHATBOT 
        try {
            javafx.scene.image.ImageView bubbleChat = new javafx.scene.image.ImageView(
                    getClass().getResource("/com/nibarra/frontend/images/avatar_bot.png").toExternalForm());
            bubbleChat.setFitWidth(64);
            bubbleChat.setFitHeight(64);
            bubbleChat.setPreserveRatio(true);
            bubbleChat.setSmooth(true);

            javafx.scene.layout.StackPane.setAlignment(bubbleChat, javafx.geometry.Pos.TOP_LEFT);
            javafx.scene.layout.StackPane.setMargin(bubbleChat, new javafx.geometry.Insets(0, 5, 0, 0));

            bubbleChat.setStyle(
                    "-fx-cursor: hand;"
                    + "-fx-effect: dropshadow(two-pass-box, rgba(0,0,0,0.35), 8, 0, 2, 2);"
                    + "-fx-opacity: 0.9;"
            );

            javafx.animation.ScaleTransition bounce = new javafx.animation.ScaleTransition(javafx.util.Duration.millis(900), bubbleChat);
            bounce.setFromX(0);
            bounce.setFromY(0);
            bounce.setToX(1);
            bounce.setToY(1);
            bounce.setInterpolator(javafx.animation.Interpolator.EASE_OUT);
            bounce.play();

            bubbleChat.setOnMouseClicked(ev -> {
                try {
                    if (tabPanePrincipal != null) {
                        tabPanePrincipal.getSelectionModel().select(3);
                        System.out.println(":= ChatBot abierto desde burbuja flotante.");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });

            if (mainContent != null && !mainContent.getChildren().contains(bubbleChat)) {
                mainContent.getChildren().add(bubbleChat);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            System.err.println("️ No se pudo crear la burbuja flotante del ChatBot.");
        }
        


    }

    @FXML
    private void cargarEquiposDesdeDAO() {
        try {
            List<Equipo> lista = equipoDAO.listarTodos();

            Platform.runLater(() -> {
                if (lblTituloChat != null) {
    String usuario = com.nibarra.frontend.util.UsuarioSesion.getNombreUsuario();
    lblTituloChat.setText("Asistente virtual de " + usuario);
}
                dataEquipos.clear();
                if (lista != null) {
                    dataEquipos.addAll(lista);
                }
                tblEquipos.setItems(dataEquipos);
                tblEquipos.refresh();
                System.out.println(":) Equipos cargados: " + dataEquipos.size());
            });

        } catch (Exception ex) {
            ex.printStackTrace();
            Platform.runLater(() -> {
                mostrarAlerta("Error al cargar los equipos: " + ex.getMessage());
            });
        }
    }

    @FXML
    private void nuevoEquipo() {

        if (txtIdEquipo != null) {
            txtIdEquipo.clear();
        }
        if (txtCodigo != null) {
            txtCodigo.clear();
        }
        if (txtTipo != null) {
            txtTipo.clear();
        }
        if (txtUbicacion != null) {
            txtUbicacion.clear();
        }

        if (cbFamilia != null) {
            cbFamilia.getSelectionModel().clearSelection();
        }
        if (txtProvincia != null) {
            txtProvincia.clear();
        }
        if (txtDireccion != null) {
            txtDireccion.clear();
        }
        if (txtHorarioBase != null) {
            txtHorarioBase.clear();
        }
        if (txtTipoDetallado != null) {
            txtTipoDetallado.clear();
        }

        if (cbEstado != null) {
            cbEstado.getSelectionModel().clearSelection();
        }

        if (tblEquipos != null) {
            tblEquipos.getSelectionModel().clearSelection();
            tblEquipos.refresh();
        }

        System.out.println("X Campos del formulario de equipo limpiados correctamente.");
    }

    @FXML
    private void guardarEquipo() {
        try {

            String codigo = (txtCodigo != null && txtCodigo.getText() != null)
                    ? txtCodigo.getText().trim().toUpperCase()
                    : null;

            String tipo = (txtTipo != null && txtTipo.getText() != null)
                    ? txtTipo.getText().trim()
                    : null;

            String ubic = (txtUbicacion != null && txtUbicacion.getText() != null)
                    ? txtUbicacion.getText().trim()
                    : null;

            String estado = (cbEstado != null) ? cbEstado.getValue() : null;

            String provincia = (txtProvincia != null && txtProvincia.getText() != null)
                    ? txtProvincia.getText().trim()
                    : "";

            String direccion = (txtDireccion != null && txtDireccion.getText() != null)
                    ? txtDireccion.getText().trim()
                    : "";

            String tipoDetallado = (txtTipoDetallado != null && txtTipoDetallado.getText() != null)
                    ? txtTipoDetallado.getText().trim()
                    : "";

            String horarioBase = (txtHorarioBase != null && txtHorarioBase.getText() != null)
                    ? txtHorarioBase.getText().trim()
                    : "";

            String familia = (cbFamilia != null) ? cbFamilia.getValue() : "";

            String usuarioActual = com.nibarra.frontend.util.UsuarioSesion.getNombreUsuario();

            if (codigo == null || codigo.isBlank()
                    || tipo == null || tipo.isBlank()
                    || ubic == null || ubic.isBlank()
                    || estado == null || estado.isBlank()) {
                mostrarAlerta(":x️ Completa todos los campos obligatorios antes de guardar.");
                return;
            }

            codigo = codigo.replaceAll("\\s+", "").toUpperCase();

            boolean esNuevo = (txtIdEquipo == null || txtIdEquipo.getText() == null || txtIdEquipo.getText().isBlank());

            if (esNuevo) {

                // Validar que el código NO exista
                if (equipoDAO.existeCodigo(codigo)) {
                    mostrarAlerta(":X️ El código '" + codigo + "' ya existe. Usa uno diferente.");
                    return;
                }

                Equipo e = new Equipo();
                e.setCodigo(codigo);
                e.setTipo(tipo);
                e.setFamilia(familia);
                e.setTipoDetallado(tipoDetallado);
                e.setUbicacion(ubic);
                e.setProvincia(provincia);
                e.setDireccion(direccion);
                e.setHorarioBase(horarioBase);
                e.setEstado(estado);
                e.setUsuarioRegistro(usuarioActual);
                e.setDisponible(true);
                e.setOcupado(false);

                boolean ok = equipoDAO.insertar(e);

                if (ok) {
                    mostrarAlerta(";) Equipo registrado correctamente.");
                    cargarEquiposDesdeDAO();
                    seleccionarPorCodigo(codigo);
                } else {
                    mostrarAlerta("X No se pudo registrar el equipo.");
                }

            } else {

                int id = Integer.parseInt(txtIdEquipo.getText());

                Equipo equipoActual = null;
                for (Equipo eq : dataEquipos) {
                    if (eq.getId() == id) {
                        equipoActual = eq;
                        break;
                    }
                }

                if (equipoActual != null && !codigo.equals(equipoActual.getCodigo())) {
                    if (equipoDAO.existeCodigo(codigo)) {
                        mostrarAlerta("X️ El código '" + codigo + "' ya existe. Usa uno diferente.");
                        return;
                    }
                }

                Equipo e = new Equipo();
                e.setId(id);
                e.setCodigo(codigo);
                e.setTipo(tipo);
                e.setFamilia(familia);
                e.setTipoDetallado(tipoDetallado);
                e.setUbicacion(ubic);
                e.setProvincia(provincia);
                e.setDireccion(direccion);
                e.setHorarioBase(horarioBase);
                e.setEstado(estado);
                e.setUsuarioRegistro(usuarioActual);
                e.setDisponible(true);
                e.setOcupado(false);

                boolean ok = equipoDAO.actualizar(e);

                if (ok) {
                    mostrarAlerta(":) Equipo actualizado correctamente.");
                    cargarEquiposDesdeDAO();
                    seleccionarPorId(id);
                } else {
                    mostrarAlerta("X Error al actualizar el equipo.");
                }
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            mostrarAlerta("X Error inesperado: " + ex.getMessage());
        }
    }

    @FXML
    private void actualizarEquipo() {
        try {

            if (txtIdEquipo == null || txtIdEquipo.getText().isBlank()) {
                mostrarAlerta("X️ Selecciona un registro primero.");
                return;
            }

            int id = Integer.parseInt(txtIdEquipo.getText());

            // Validar campos 
            String codigo = (txtCodigo != null && txtCodigo.getText() != null)
                    ? txtCodigo.getText().trim().toUpperCase()
                    : null;

            String tipo = (txtTipo != null && txtTipo.getText() != null)
                    ? txtTipo.getText().trim()
                    : null;

            String ubic = (txtUbicacion != null && txtUbicacion.getText() != null)
                    ? txtUbicacion.getText().trim()
                    : null;

            String estado = (cbEstado != null) ? cbEstado.getValue() : null;

            if (codigo == null || codigo.isBlank()
                    || tipo == null || tipo.isBlank()
                    || ubic == null || ubic.isBlank()
                    || estado == null || estado.isBlank()) {
                mostrarAlerta("⚠️ Completa todos los campos obligatorios.");
                return;
            }

            String usuarioActual = com.nibarra.frontend.util.UsuarioSesion.getNombreUsuario();

            String familia = (cbFamilia != null) ? cbFamilia.getValue() : "";
            String tipoDet = (txtTipoDetallado != null && txtTipoDetallado.getText() != null)
                    ? txtTipoDetallado.getText().trim() : "";
            String provincia = (txtProvincia != null && txtProvincia.getText() != null)
                    ? txtProvincia.getText().trim() : "";
            String direccion = (txtDireccion != null && txtDireccion.getText() != null)
                    ? txtDireccion.getText().trim() : "";
            String horario = (txtHorarioBase != null && txtHorarioBase.getText() != null)
                    ? txtHorarioBase.getText().trim() : "";

            Equipo equipoActual = null;
            for (Equipo eq : dataEquipos) {
                if (eq.getId() == id) {
                    equipoActual = eq;
                    break;
                }
            }

            if (equipoActual != null && !codigo.equals(equipoActual.getCodigo())) {
                if (equipoDAO.existeCodigo(codigo)) {
                    mostrarAlerta("X️ El código '" + codigo + "' ya existe. Usa uno diferente.");
                    return;
                }
            }

            Equipo e = new Equipo();
            e.setId(id);
            e.setCodigo(codigo);
            e.setTipo(tipo);
            e.setFamilia(familia);
            e.setTipoDetallado(tipoDet);
            e.setUbicacion(ubic);
            e.setProvincia(provincia);
            e.setDireccion(direccion);
            e.setHorarioBase(horario);
            e.setEstado(estado);
            e.setUsuarioRegistro(usuarioActual);
            e.setDisponible(true);
            e.setOcupado(false);

            boolean ok = equipoDAO.actualizar(e);

            if (ok) {
                mostrarAlerta(":) Equipo actualizado correctamente.");
                cargarEquiposDesdeDAO();
                seleccionarPorId(id);
            } else {
                mostrarAlerta("X Error al actualizar el equipo.");
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            mostrarAlerta("Error inesperado: " + ex.getMessage());
        }
    }

    @FXML
    private void eliminarEquipo() {
        try {
            if (txtIdEquipo == null || txtIdEquipo.getText() == null || txtIdEquipo.getText().isBlank()) {
                System.out.println("Selecciona un registro para eliminar.");
                return;
            }
            int id = Integer.parseInt(txtIdEquipo.getText());
            boolean ok = equipoDAO.eliminar(id);
            if (ok) {
                System.out.println("Eliminado OK.");
                cargarEquiposDesdeDAO();
                nuevoEquipo();
            } else {
                System.out.println("Error eliminando.");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void seleccionarPorCodigo(String codigo) {
        for (int i = 0; i < dataEquipos.size(); i++) {
            if (codigo.equals(dataEquipos.get(i).getCodigo())) {
                tblEquipos.getSelectionModel().select(i);
                tblEquipos.scrollTo(i);
                break;
            }
        }
    }

    private void seleccionarPorId(Integer id) {
        for (int i = 0; i < dataEquipos.size(); i++) {
            if (id.equals(dataEquipos.get(i).getId())) {
                tblEquipos.getSelectionModel().select(i);
                tblEquipos.scrollTo(i);
                break;
            }
        }
    }

    // MANTENIMIENTOS
    @FXML
    private void cargarMantenimientos() {
        dataMants.clear();
        dataMants.addAll(mantDAO.listarTodos());
        Platform.runLater(() -> filtrarMantenimientos(null));
    }

    @FXML
    private void nuevoMantenimiento() {
        txtFolio.clear();
        txtEquipo.clear();
        cbTipoMant.setValue(null);
        cbEstadoMant.setValue("Por hacer");
        dpFechaProg.setValue(null);
        txtDescripcion.clear();
        sldAvance.setValue(0);
        pbAvance.setProgress(0);
    }

    @FXML
    private void guardarMantenimiento() {
        String folio = txtFolio.getText();
        String equipo = txtEquipo.getText();
        String tipo = cbTipoMant.getValue();
        String estado = cbEstadoMant.getValue();
        LocalDate fecha = dpFechaProg.getValue();
        String desc = txtDescripcion.getText();
        int avance = (int) sldAvance.getValue();

        if (folio == null || folio.isBlank() || equipo == null || equipo.isBlank()) {
            mostrarAlerta("X️ Completa el folio y el equipo antes de guardar.");
            return;
        }

        int idEquipo = obtenerIdEquipo(equipo);
        if (idEquipo == -1) {
            mostrarAlerta("X Equipo no encontrado: " + equipo);
            return;
        }

        boolean folioExiste = existeFolio(folio);

        // PARA LOS FOLIOS, AQUI SE DECIDE SI QUIERE MAS FOLIOS O NO NOTA: al editar ESTO hay QUE EDITAR EL DAO
        if (!folioExiste) {
            int foliosActivos = contarFoliosActivosPorEquipo(idEquipo);

            if (foliosActivos >= 2) {
                mostrarAlerta("X️ Este equipo ya tiene 2 mantenimientos activos.\n"
                        + "No se pueden agregar más hasta completar uno existente.\n\n"
                        + "Marca alguno como 'Terminada' para liberar espacio.");
                return;
            }
        }

        Mantenimiento m = new Mantenimiento(
                null, folio, equipo, tipo, estado, avance, fecha, desc
        );

        boolean ok;
        if (folioExiste) {

            ok = mantDAO.actualizar(m, idEquipo);
            if (ok) {
                mostrarAlerta(":) Mantenimiento actualizado correctamente.");
            } else {
                mostrarAlerta("x Error al actualizar el mantenimiento.");
            }
        } else {

            ok = mantDAO.insertar(m, idEquipo);
            if (ok) {
                mostrarAlerta(":) Mantenimiento guardado correctamente.");
            } else {
                mostrarAlerta("❌ Error insertando mantenimiento.");
            }
        }

        if (ok) {
            cargarMantenimientos();
        }
    }

    private boolean existeFolio(String folio) {
        String sql = "SELECT COUNT(*) FROM orden_servicio WHERE folio=?";
        try (var cn = com.nibarra.frontend.util.Db.getConnection(); var ps = cn.prepareStatement(sql)) {
            ps.setString(1, folio);
            try (var rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    private int contarFoliosActivosPorEquipo(int idEquipo) {
        String sql = "SELECT COUNT(*) FROM orden_servicio WHERE id_equipo=? AND estado != 'Terminada'";
        try (var cn = com.nibarra.frontend.util.Db.getConnection(); var ps = cn.prepareStatement(sql)) {
            ps.setInt(1, idEquipo);
            try (var rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    @FXML
    private void filtrarMantenimientos(ActionEvent event) {
        try {

            String tipoFiltro = (cbFiltroTipo != null) ? cbFiltroTipo.getValue() : "Todos";
            String estadoFiltro = (cbFiltroEstado != null) ? cbFiltroEstado.getValue() : "Todos";

            LocalDate fechaDesde = (dpDesde != null) ? dpDesde.getValue() : null;
            LocalDate fechaHasta = (dpHasta != null) ? dpHasta.getValue() : null;

            List<Mantenimiento> filtrados = mantDAO.listarTodos().stream()
                    .filter(m -> {

                        if ("Todos".equals(tipoFiltro)) {
                            return true;
                        }
                        return m.getTipoMant().equals(tipoFiltro);
                    })
                    .filter(m -> {

                        if ("Todos".equals(estadoFiltro)) {
                            return true;
                        }
                        return m.getEstado().equals(estadoFiltro);
                    })
                    .filter(m -> {

                        if (fechaDesde == null) {
                            return true;
                        }
                        return !m.getFechaProgramada().isBefore(fechaDesde);
                    })
                    .filter(m -> {

                        if (fechaHasta == null) {
                            return true;
                        }
                        return !m.getFechaProgramada().isAfter(fechaHasta);
                    })
                    .toList();

            dataMants.setAll(filtrados);
            System.out.println("O Fecha desde: " + fechaDesde + " | hasta: " + fechaHasta);
            System.out.println(":) Tipo: " + tipoFiltro + " | Estado: " + estadoFiltro);
            System.out.println("Total en BD: " + mantDAO.listarTodos().size());

            StringBuilder msg = new StringBuilder(":) Filtrados " + filtrados.size() + " mantenimientos");
            if (fechaDesde != null) {
                msg.append(" desde ").append(fechaDesde);
            }
            if (fechaHasta != null) {
                msg.append(" hasta ").append(fechaHasta);
            }
            System.out.println(msg);

        } catch (Exception ex) {
            ex.printStackTrace();
            mostrarAlerta("X Error al filtrar: " + ex.getMessage());
        }
    }
    // NO TOCAR el dao depende de esto

    @FXML
    private void refrescarMantenimientos(ActionEvent event) {
        try {
            cargarMantenimientos();
            System.out.println("Mantenimientos recargados correctamente.");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @FXML
    private void cambiarEstado() {
        com.nibarra.frontend.model.Mantenimiento sel = tblMantenimientos.getSelectionModel().getSelectedItem();
        if (sel == null) {
            return;
        }
        sel.setEstado(cbEstadoMant.getValue());
        sel.setAvance((int) sldAvance.getValue());
        int idEquipo = obtenerIdEquipo(sel.getEquipo());
        mantDAO.actualizar(sel, idEquipo);
        cargarMantenimientos();
    }

    @FXML
    private void marcarTerminada() {
        sldAvance.setValue(100);
        pbAvance.setProgress(1.0);
        cbEstadoMant.setValue("Terminada");
        cambiarEstado();
    }

    private void mostrarAlerta(String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Información");
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    @FXML
    private void estadoPorHacer(ActionEvent event) {
        try {

            Mantenimiento mantenimientoSeleccionado = tblMantenimientos.getSelectionModel().getSelectedItem();

            if (mantenimientoSeleccionado == null) {
                mostrarAlerta("Selecciona un mantenimiento primero para cambiar su estado a 'Por hacer'.");
                return;
            }

            mantenimientoSeleccionado.setEstado("Por hacer");

            tblMantenimientos.refresh();

            mostrarAlerta("El mantenimiento se ha marcado como 'Por hacer' correctamente.");
        } catch (Exception e) {
            e.printStackTrace();
            mostrarAlerta("Ocurrió un error al cambiar el estado a 'Por hacer'.");
        }
    }

    private void filtrarPorEstado(String estado) {
        List<Mantenimiento> filtrados = mantDAO.listarTodos().stream()
                .filter(m -> m.getEstado().equalsIgnoreCase(estado))
                .toList();
        dataMants.setAll(filtrados);
        System.out.println("Filtrados por estado: " + estado);
    }

    @FXML
    private void estadoEnProceso(ActionEvent event) {
        filtrarPorEstado("En proceso");
    }

    @FXML
    private void estadoTerminado(ActionEvent event) {
        filtrarPorEstado("Terminado");
    }

    @FXML
    private void estadoEnEspera(ActionEvent event) {
        filtrarPorEstado("En espera");
    }

    @FXML
    private void estadoEnRevision(ActionEvent event) {
        try {
            Mantenimiento sel = tblMantenimientos.getSelectionModel().getSelectedItem();
            if (sel == null) {
                mostrarAlerta("Selecciona un mantenimiento antes de marcarlo como 'En revisión'.");
                return;
            }

            sel.setEstado("En revisión");
            tblMantenimientos.refresh();
            mostrarAlerta("El mantenimiento se ha marcado como 'En revisión'.");
        } catch (Exception e) {
            e.printStackTrace();
            mostrarAlerta("Ocurrió un error al marcar el mantenimiento como 'En revisión'.");
        }
    }

    @FXML
    private void estadoTerminada(ActionEvent event) {
        try {
            Mantenimiento sel = tblMantenimientos.getSelectionModel().getSelectedItem();
            if (sel == null) {
                mostrarAlerta("Selecciona un mantenimiento antes de marcarlo como 'Terminado'.");
                return;
            }

            sel.setEstado("Terminada");
            sel.setAvance(100);
            mantDAO.actualizar(sel, obtenerIdEquipo(sel.getEquipo()));
            tblMantenimientos.refresh();
            mostrarAlerta("El mantenimiento se ha marcado como 'Terminado'.");
        } catch (Exception e) {
            e.printStackTrace();
            mostrarAlerta("Ocurrió un error al marcar el mantenimiento como 'Terminado'.");
        }
    }

    @FXML
    private void eliminarMantenimiento() {
        com.nibarra.frontend.model.Mantenimiento sel = tblMantenimientos.getSelectionModel().getSelectedItem();
        if (sel == null) {
            return;
        }
        mantDAO.eliminar(sel.getFolio());
        cargarMantenimientos();
    }

    @FXML
    private void ajustarAvanceDesdeSlider() {
        if (pbAvance != null && sldAvance != null) {
            pbAvance.setProgress(sldAvance.getValue() / 100.0);
        }
    }

    private int obtenerIdEquipo(String codigoEquipo) {
        String sql = "SELECT id FROM equipo WHERE codigo = ?";
        try (java.sql.Connection cn = com.nibarra.frontend.util.Db.getConnection(); java.sql.PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, codigoEquipo);
            try (java.sql.ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1;
    }

    // CALENDARIO
    private void dibujarCalendario(LocalDate fechaBase) {
        gridCalendario.getChildren().clear();
        int anio = fechaBase.getYear();
        int mes = fechaBase.getMonthValue();

        java.time.LocalDate primerDia = LocalDate.of(anio, mes, 1);
        int diaInicio = primerDia.getDayOfWeek().getValue(); // 1=Lunes, 7=Domingo
        int diasEnMes = primerDia.lengthOfMonth();

        List<com.nibarra.frontend.model.EventoCalendario> eventosMes = calendarioDAO.listarPorMes(anio, mes);

        int fila = 0;
        int columna = diaInicio - 1;

        for (int dia = 1; dia <= diasEnMes; dia++) {
            javafx.scene.layout.VBox celda = new javafx.scene.layout.VBox();
            celda.setPrefSize(70, 70);
            celda.setStyle("-fx-border-color:#CFD8DC; -fx-background-color:white;");
            celda.setSpacing(3);
            celda.setPadding(new javafx.geometry.Insets(4));

            javafx.scene.control.Label lblDia = new javafx.scene.control.Label(String.valueOf(dia));
            lblDia.setStyle("-fx-font-weight:bold; -fx-text-fill:#37474F;");

            celda.getChildren().add(lblDia);

            LocalDate fechaActual = LocalDate.of(anio, mes, dia);
            for (com.nibarra.frontend.model.EventoCalendario ev : eventosMes) {
                if (ev.getFecha().equals(fechaActual)) {
                    javafx.scene.control.Label lblEvento = new javafx.scene.control.Label("• " + ev.getFolio());
                    lblEvento.setStyle("-fx-text-fill:#1976D2;");
                    celda.getChildren().add(lblEvento);
                }
            }

            celda.setOnMouseClicked(e -> {
                lblEventosDia.setText("Eventos del " + fechaActual);
                eventosDia.clear();
                eventosDia.addAll(calendarioDAO.listarPorDia(fechaActual));
            });

            gridCalendario.add(celda, columna, fila);
            columna++;
            if (columna > 6) {
                columna = 0;
                fila++;
            }
        }
    }

    @FXML
    private void actualizarVistaCalendario() {
        try {
            int mesSeleccionado = cbMes.getSelectionModel().getSelectedIndex() + 1; // Enero = 0
            int anioSeleccionado = Integer.parseInt(cbAnio.getValue());

            LocalDate fechaNueva = LocalDate.of(anioSeleccionado, mesSeleccionado, 1);
            dpFechaBase.setValue(fechaNueva);
            dibujarCalendario(fechaNueva);

            System.out.println("Calendario actualizado: " + fechaNueva);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void irAHoy() {
        LocalDate hoy = LocalDate.now();
        dpFechaBase.setValue(hoy);

        if (cbMes != null) {
            cbMes.getSelectionModel().select(hoy.getMonthValue() - 1);
        }
        if (cbAnio != null) {
            cbAnio.setValue(String.valueOf(hoy.getYear()));
        }

        dibujarCalendario(hoy);
        System.out.println("Volviendo a la fecha actual: " + hoy);
    }

    @FXML
    private void refrescarCalendario() {
        try {

            if (cbAnio.getValue() == null || cbMes.getSelectionModel().getSelectedIndex() < 0) {
                System.err.println("x️ Selecciona un mes y un año antes de refrescar el calendario.");
                return;
            }

            int anio = Integer.parseInt(cbAnio.getValue());
            int mes = cbMes.getSelectionModel().getSelectedIndex() + 1; // Enero = 0 → +1 = 1

            System.out.println("Refrescando calendario para: " + anio + "-" + mes);

            LocalDate fechaNueva = LocalDate.of(anio, mes, 1);
            dpFechaBase.setValue(fechaNueva);

            dibujarCalendario(fechaNueva);

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("X️ Error al refrescar calendario: " + e.getMessage());
        }
    }

    @FXML
    private void agregarEvento() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/nibarra/frontend/view/AgregarEvento.fxml"));
            Stage stage = new Stage();
            stage.setTitle("Agregar nuevo evento");
            stage.setScene(new Scene(loader.load()));
            stage.setResizable(false);
            stage.showAndWait();

            refrescarCalendario();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void verDetalleEvento() {
        try {
            var seleccionado = tblEventosDia.getSelectionModel().getSelectedItem();
            if (seleccionado == null) {
                System.out.println("Selecciona un evento para ver su detalle.");
                return;
            }

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/nibarra/frontend/view/DetalleEvento.fxml"));
            Stage stage = new Stage();
            stage.setTitle("Detalle del evento");
            stage.setScene(new Scene(loader.load()));

            DetalleEventoController ctrl = loader.getController();
            ctrl.setDatos(
                    seleccionado.getFolio(),
                    seleccionado.getTipo(),
                    seleccionado.getEstado(),
                    seleccionado.getFecha().toString()
            );

            stage.setResizable(false);
            stage.showAndWait();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void editarEvento() {
        try {
            var seleccionado = tblEventosDia.getSelectionModel().getSelectedItem();
            if (seleccionado == null) {
                System.out.println("Selecciona un evento para editarlo.");
                return;
            }

            TextInputDialog dialog = new TextInputDialog(seleccionado.getEstado());
            dialog.setTitle("Editar evento");
            dialog.setHeaderText("Modificar estado del mantenimiento:");
            dialog.setContentText("Nuevo estado:");

            dialog.showAndWait().ifPresent(nuevoEstado -> {
                try (var cn = com.nibarra.frontend.util.Db.getConnection(); var ps = cn.prepareStatement(
                        "UPDATE orden_servicio SET estado=? WHERE folio=?")) {
                    ps.setString(1, nuevoEstado);
                    ps.setString(2, seleccionado.getFolio());
                    int filas = ps.executeUpdate();
                    if (filas > 0) {
                        System.out.println("Evento actualizado correctamente.");
                        refrescarCalendario();
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void eliminarEvento() {
        try {
            var seleccionado = tblEventosDia.getSelectionModel().getSelectedItem();
            if (seleccionado == null) {
                System.out.println("Selecciona un evento para eliminarlo.");
                return;
            }

            Alert alerta = new Alert(Alert.AlertType.CONFIRMATION);
            alerta.setTitle("Eliminar evento");
            alerta.setHeaderText("¿Seguro que deseas eliminar este evento?");
            alerta.setContentText("Folio: " + seleccionado.getFolio());
            var resultado = alerta.showAndWait();

            if (resultado.isPresent() && resultado.get() == ButtonType.OK) {
                try (var cn = com.nibarra.frontend.util.Db.getConnection(); var ps = cn.prepareStatement("DELETE FROM orden_servicio WHERE folio=?")) {
                    ps.setString(1, seleccionado.getFolio());
                    ps.executeUpdate();
                    System.out.println("Evento eliminado correctamente.");
                    refrescarCalendario();
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // CHATBOT
    @FXML
    private void limpiarChat() {
        if (boxMensajes != null) {
            boxMensajes.getChildren().removeIf(node -> {
                if (!(node instanceof javafx.scene.layout.HBox fila)) {
                    return false;
                }

                boolean tieneBurbuja = fila.getChildren().stream()
                        .anyMatch(c -> c instanceof javafx.scene.control.Label);

                String id = fila.getId();
                boolean esSugerencia = (id != null && id.equalsIgnoreCase("boxSugerencias"));

                return tieneBurbuja && !esSugerencia;
            });
            System.out.println(":) Se limpiaron solo las burbujas de mensajes del chat.");
        }

        if (boxSugerencias != null && !boxSugerencias.isVisible()) {
            boxSugerencias.setVisible(true);
        }
    }

    @FXML
    private void exportarChat() {
        System.out.println("Exportar chat (implementar).");
    }

    @FXML
    private void enviarMensaje() {
        if (txtMensaje == null) {
            return;
        }
        String texto = txtMensaje.getText();
        if (texto == null || texto.isBlank()) {
            return;
        }

String respuestaLocal = generarRespuestaContextual(texto);
if (!respuestaLocal.equals("No tengo datos precisos sobre eso, pero puedo revisar mantenimientos, equipos o usuarios si lo deseas.")) {
    agregarBurbujaBot(respuestaLocal);
    return;
}

        agregarBurbujaUsuario(texto);
        txtMensaje.clear();

        final var bubbleEscribiendo = new javafx.scene.control.Label("Escribiendo…");
        bubbleEscribiendo.setWrapText(true);
        bubbleEscribiendo.setMaxWidth(480);
        bubbleEscribiendo.setStyle(
                "-fx-background-color:#E3F2FD; -fx-border-color:#BBDEFB; -fx-text-fill:#1565C0; "
                + "-fx-padding:10; -fx-background-radius:10; -fx-border-radius:10;"
        );
        javafx.scene.layout.HBox fila = new javafx.scene.layout.HBox();
        fila.setSpacing(8);
        fila.setAlignment(javafx.geometry.Pos.CENTER_LEFT);
        fila.getChildren().addAll(crearAvatar("/com/nibarra/frontend/images/avatar_bot.png"), bubbleEscribiendo);
        boxMensajes.getChildren().add(fila);

        if (btnEnviar != null) {
            btnEnviar.setDisable(true);
        }
        if (btnSugerencias != null) {
            btnSugerencias.setDisable(true);
        }

        String json = "{\"mensaje\":\"" + escaparJson(texto) + "\"}";

        if (texto.toLowerCase().contains("hola") || texto.toLowerCase().contains("usuario") || texto.toLowerCase().contains("equipo")) {
            procesarMensajeInteligente(texto);
            return;
        }

        // ESTA EL EL CORAZON DELA API
        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(CHAT_BASE_URL + "/api/chat"))
                .timeout(Duration.ofSeconds(10))
                .header("Content-Type", "application/json; charset=UTF-8")
                .POST(HttpRequest.BodyPublishers.ofString(json, StandardCharsets.UTF_8))
                .build();

        CompletableFuture
                .supplyAsync(() -> {
                    try {
                        HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
                        int code = resp.statusCode();
                        String body = resp.body();
                        if (code >= 200 && code < 300) {
                            String reply = extraerReply(body); // parsea {"reply":"..."}
                            if (reply == null || reply.isBlank()) {
                                reply = "Respuesta vacía del servidor.";
                            }
                            return new ResultadoOk(reply);
                        } else {
                            return new ResultadoError("HTTP " + code + " — " + body);
                        }
                    } catch (Exception ex) {
                        return new ResultadoError("Error de red: " + ex.getMessage());
                    }
                })
                .thenAccept(result -> Platform.runLater(() -> {

            boxMensajes.getChildren().remove(fila);

            if (result instanceof ResultadoOk ok) {
                agregarBurbujaBot(ok.texto());
            } else if (result instanceof ResultadoError err) {
                agregarBurbujaBot("No pude responder. " + err.mensaje());
            }

            if (scrollChat != null) {
                scrollChat.layout();
                scrollChat.setVvalue(1.0);
            }

            if (btnEnviar != null) {
                btnEnviar.setDisable(false);
            }
            if (btnSugerencias != null) {
                btnSugerencias.setDisable(false);
            }
        }));
    }

    @FXML
    private void procesarMensajeInteligente(String mensajeUsuario) {
        String interpretado = interpretarMensajeUsuario(mensajeUsuario);

        String respuesta;

        if (interpretado.contains("saludo")) {
            String usuario = com.nibarra.frontend.util.UsuarioSesion.getNombreUsuario();
            respuesta = "¡Hola " + usuario + "! 😊 Soy tu asistente técnico. ¿Deseas conocer el estado de tus equipos o los mantenimientos activos?";
        } else if (interpretado.contains("estado") && interpretado.contains("mantenimiento")) {
            respuesta = "Actualmente hay " + dataMants.size() + " mantenimientos registrados. Puedo mostrarte los que están en proceso o los terminados.";
        } else if (interpretado.contains("equipo") && interpretado.contains("información")) {
            respuesta = "Puedo darte información detallada del equipo, como su ubicación, estado y familia. Solo indícame el código del equipo.";
        } else if (interpretado.contains("usuario") || interpretado.contains("quién soy")) {
            String usuario = com.nibarra.frontend.util.UsuarioSesion.getNombreUsuario();
            respuesta = "Estás logueado como: " + usuario + ".";
        } else {
            respuesta = "No tengo datos precisos para esa consulta, pero puedo ayudarte con estados, equipos o mantenimientos.";
        }

        agregarBurbujaBot(respuesta);
    }
    
    private String generarRespuestaContextual(String texto) {
    String lower = texto.toLowerCase();

    if (lower.contains("cuántos equipos") || lower.contains("cantidad de equipos")) {
        return "Actualmente hay " + dataEquipos.size() + " equipos registrados en el sistema.";
    }

    if (lower.contains("mantenimientos activos")) {
        long activos = dataMants.stream()
                .filter(m -> !m.getEstado().equalsIgnoreCase("Terminada"))
                .count();
        return "Existen " + activos + " mantenimientos activos en este momento.";
    }

    if (lower.contains("usuarios conectados") || lower.contains("sesiones")) {
        return "Hay " + dataHistorial.size() + " sesiones registradas recientemente.";
    }

    if (lower.contains("fecha") && lower.contains("hoy")) {
        return "Hoy es " + LocalDate.now() + ".";
    }

    return "No tengo datos precisos sobre eso, pero puedo revisar mantenimientos, equipos o usuarios si lo deseas.";
}


    private String interpretarMensajeUsuario(String texto) {
        String lower = texto.toLowerCase();

        if (lower.matches(".*\\d+.*")) {
            if (lower.contains("folio") || lower.startsWith("f")) {
                return "Consulta sobre el folio " + lower.replaceAll("[^0-9]", "");
            } else if (lower.contains("equipo")) {
                return "Información del equipo " + lower.replaceAll("[^0-9]", "");
            } else {
                return "Consulta general sobre número " + lower.replaceAll("[^0-9]", "");
            }
        }

        if (lower.contains("hola") || lower.contains("buenas")) {
            return "saludo del usuario";
        }

        if (lower.contains("estado")) {
            return "Pregunta sobre estado de equipos o mantenimientos";
        }
        if (lower.contains("equipo") && lower.contains("hace")) {
            return "Consulta sobre la función o descripción de un equipo";
        }

        return texto;
    }

    private String escaparJson(String s) {
        StringBuilder sb = new StringBuilder(s.length() + 16);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"' ->
                    sb.append("\\\"");
                case '\\' ->
                    sb.append("\\\\");
                case '\b' ->
                    sb.append("\\b");
                case '\f' ->
                    sb.append("\\f");
                case '\n' ->
                    sb.append("\\n");
                case '\r' ->
                    sb.append("\\r");
                case '\t' ->
                    sb.append("\\t");
                default -> {
                    if (c < 0x20) {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
                }
            }
        }
        return sb.toString();
    }

    private String extraerReply(String body) {

        int i = body.indexOf("\"reply\"");
        if (i < 0) {
            return null;
        }
        int c = body.indexOf(':', i);
        if (c < 0) {
            return null;
        }
        int q1 = body.indexOf('"', c);
        if (q1 < 0) {
            return null;
        }

        StringBuilder out = new StringBuilder();
        boolean escaping = false;
        for (int j = q1 + 1; j < body.length(); j++) {
            char ch = body.charAt(j);
            if (escaping) {

                switch (ch) {
                    case '"' ->
                        out.append('"');
                    case '\\' ->
                        out.append('\\');
                    case 'n' ->
                        out.append('\n');
                    case 'r' ->
                        out.append('\r');
                    case 't' ->
                        out.append('\t');
                    case 'b' ->
                        out.append('\b');
                    case 'f' ->
                        out.append('\f');
                    case 'u' -> {
                        if (j + 4 < body.length()) {
                            String hex = body.substring(j + 1, j + 5);
                            try {
                                out.append((char) Integer.parseInt(hex, 16));
                                j += 4;
                            } catch (NumberFormatException ignore) {
                            }
                        }
                    }
                    default ->
                        out.append(ch);
                }
                escaping = false;
            } else {
                if (ch == '\\') {
                    escaping = true;
                } else if (ch == '"') {
                    break;
                } else {
                    out.append(ch);
                }
            }
        }
        return out.toString();
    }

    private sealed interface Resultado permits ResultadoOk, ResultadoError {
    }

    private record ResultadoOk(String texto) implements Resultado {

    }

    private record ResultadoError(String mensaje) implements Resultado {

    }

    @FXML
    private void mostrarSugerencias() {
        if (boxSugerencias != null) {
            boxSugerencias.setVisible(!boxSugerencias.isVisible());
        }
    }

    @FXML
    private void sugProximoMantenimiento() {
        if (txtMensaje != null) {
            txtMensaje.setText("¿Cuál es el próximo mantenimiento programado?");
        }
        enviarMensaje();
    }

    @FXML
    private void sugEstadoFolio() {
        if (txtMensaje != null) {
            txtMensaje.setText("¿Cuál es el estado del Folio-82?");
        }
        enviarMensaje();
    }

    @FXML
    private void sugPendientes() {
        if (txtMensaje != null) {
            txtMensaje.setText("¿Cuántos mantenimientos pendientes hay?");
        }
        enviarMensaje();
    }

    @FXML
    private void sugHorario() {
        if (txtMensaje != null) {
            txtMensaje.setText("¿Cuál es el horario del técnico asignado hoy?");
        }
        enviarMensaje();
    }

    private void agregarBurbujaUsuario(String texto) {
        if (boxMensajes == null || scrollChat == null) {
            return;
        }

        javafx.scene.layout.HBox fila = new javafx.scene.layout.HBox();
        fila.setSpacing(8);
        fila.setAlignment(javafx.geometry.Pos.CENTER_RIGHT);

        Label lbl = new Label(texto);
        lbl.setWrapText(true);
        lbl.setStyle(
                "-fx-background-color:#E8F5E9; -fx-border-color:#C8E6C9; -fx-text-fill:#2E7D32; "
                + "-fx-padding:10; -fx-background-radius:10; -fx-border-radius:10; "
                + "-fx-font-size:14px; -fx-font-family:'Segoe UI';"
        );

        double anchoMaximo = scrollChat.getViewportBounds().getWidth() * 0.8;
        lbl.setMaxWidth(anchoMaximo);

        ImageView avatar = crearAvatar("/com/nibarra/frontend/images/avatar_user.png");
        fila.getChildren().addAll(lbl, avatar);
        boxMensajes.getChildren().add(fila);

        // Auto-scroll al final
        Platform.runLater(() -> scrollChat.setVvalue(1.0));
    }

    private void agregarBurbujaBot(String texto) {
        if (boxMensajes == null || scrollChat == null) {
            return;
        }

        javafx.scene.layout.HBox fila = new javafx.scene.layout.HBox();
        fila.setSpacing(10);
        fila.setAlignment(javafx.geometry.Pos.CENTER_LEFT);

        ImageView avatar = crearAvatar("/com/nibarra/frontend/images/avatar_bot.png");

        Label lbl = new Label(texto);
        lbl.setWrapText(true);
        lbl.setStyle(
                "-fx-background-color: linear-gradient(to bottom right, #E3F2FD, #BBDEFB);"
                + "-fx-border-color: #90CAF9;"
                + "-fx-text-fill: #0D47A1;"
                + "-fx-padding: 10;"
                + "-fx-background-radius: 14;"
                + "-fx-border-radius: 14;"
                + "-fx-font-size: 14px;"
                + "-fx-font-family: 'Segoe UI';"
                + "-fx-effect: dropshadow(two-pass-box, rgba(0,0,0,0.15), 4, 0, 1, 1);"
        );

        lbl.setOpacity(0);
        javafx.animation.FadeTransition ft = new javafx.animation.FadeTransition(javafx.util.Duration.millis(300), lbl);
        ft.setFromValue(0);
        ft.setToValue(1);
        ft.play();

        double anchoMaximo = scrollChat.getViewportBounds().getWidth() * 0.8;
        lbl.setMaxWidth(anchoMaximo);

        fila.getChildren().addAll(avatar, lbl);
        boxMensajes.getChildren().add(fila);

        Platform.runLater(() -> scrollChat.setVvalue(1.0));
    }

    private ImageView crearAvatar(String ruta) {
        try {
            Image img = new Image(getClass().getResourceAsStream(ruta));
            ImageView iv = new ImageView(img);
            iv.setFitWidth(36);
            iv.setFitHeight(36);
            iv.setPreserveRatio(true);
            iv.setSmooth(true);
            return iv;
        } catch (Exception e) {
            ImageView iv = new ImageView();
            iv.setFitWidth(0);
            iv.setFitHeight(0);
            return iv;
        }
    }

    // - ESTADÍSTICAS 
    @FXML
    private void actualizarEstadisticas() {
        System.out.println("Actualizando estadísticas desde MySQL...");

        try {

            double promedio = estDAO.obtenerPromedioAvance();
            pbAvanceGlobal.setProgress(promedio);
            lblPorcentajeAvance.setText(String.format("%.1f %% completado", promedio * 100));

            var conteos = estDAO.obtenerConteoPorTipo();

            int total = conteos.values().stream().mapToInt(Integer::intValue).sum();
            int pred = conteos.getOrDefault("Predictivo", 0);
            int prev = conteos.getOrDefault("Preventivo", 0);
            int corr = conteos.getOrDefault("Correctivo", 0);

            chartTipoMant.getData().clear();
            chartTipoMant.getData().add(new javafx.scene.chart.PieChart.Data("Predictivo", pred));
            chartTipoMant.getData().add(new javafx.scene.chart.PieChart.Data("Preventivo", prev));
            chartTipoMant.getData().add(new javafx.scene.chart.PieChart.Data("Correctivo", corr));

            lblPredictivo.setText(String.format("Predictivo: %d (%.1f %%)", pred, total > 0 ? pred * 100.0 / total : 0));
            lblPreventivo.setText(String.format("Preventivo: %d (%.1f %%)", prev, total > 0 ? prev * 100.0 / total : 0));
            lblCorrectivo.setText(String.format("Correctivo: %d (%.1f %%)", corr, total > 0 ? corr * 100.0 / total : 0));

            var uso = estDAO.obtenerUsoChatbot();
            lblMensajesTotales.setText("Total mensajes: " + uso.get("mensajes"));
            lblPreguntas.setText("Consultas usuario: " + uso.get("preguntas"));
            lblRespuestas.setText("Respuestas bot: " + uso.get("respuestas"));

            chartUsoChatbot.getData().clear();
            javafx.scene.chart.XYChart.Series<String, Number> serie = new javafx.scene.chart.XYChart.Series<>();
            serie.setName("Interacciones");
            serie.getData().add(new javafx.scene.chart.XYChart.Data<>("Mensajes", uso.get("mensajes")));
            serie.getData().add(new javafx.scene.chart.XYChart.Data<>("Preguntas", uso.get("preguntas")));
            serie.getData().add(new javafx.scene.chart.XYChart.Data<>("Respuestas", uso.get("respuestas")));
            chartUsoChatbot.getData().add(serie);

            System.out.println(":) Estadísticas actualizadas correctamente.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void exportarEstadisticas() {
        System.out.println("Exportar estadísticas (implementar).");
    }

    //  NAVEGACIÓN
    @FXML
    private void abrirEquipos(ActionEvent e) {
        try {
            tabPanePrincipal.getSelectionModel().select(0);
        } catch (Exception ex) {
        }
    }

    @FXML
    private void abrirMantenimientos(ActionEvent e) {
        try {
            tabPanePrincipal.getSelectionModel().select(1);
        } catch (Exception ex) {
        }
    }

    @FXML
    private void abrirCalendario(ActionEvent e) {
        try {
            tabPanePrincipal.getSelectionModel().select(2);
        } catch (Exception ex) {
        }
    }

    @FXML
    private void abrirChatbot(ActionEvent e) {
        try {
            tabPanePrincipal.getSelectionModel().select(3);
        } catch (Exception ex) {
        }
    }

    @FXML
    private void abrirEstadisticas(ActionEvent e) {
        try {
            tabPanePrincipal.getSelectionModel().select(4);
        } catch (Exception ex) {
        }
    }

    @FXML
    private void cerrarSesion(ActionEvent event) {
        try (Connection conn = com.nibarra.frontend.util.Db.getConnection()) {
            PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO sesion_usuario (id_usuario, usuario, evento) VALUES (?, ?, 'LOGOUT')"
            );
            ps.setInt(1, UsuarioSesion.getIdActual());
            ps.setString(2, UsuarioSesion.getNombreUsuario());
            ps.executeUpdate();
            System.out.println(":) Sesión cerrada y registrada correctamente.");
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarAlerta("Error al registrar el cierre de sesión.");
        }

        // Evitar NullPointerException si la escena no está inicializada
        try {
            if (App.scene != null) {
                App.setRoot("Login");
            } else {

                javafx.fxml.FXMLLoader loader = new javafx.fxml.FXMLLoader(
                        getClass().getResource("/com/nibarra/frontend/view/Login.fxml"));
                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                stage.setScene(new Scene(loader.load()));
                stage.show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            mostrarAlerta("No se pudo volver al login.");
        }
    }

// Historial Sesion
    private void cargarHistorialSesiones() {

        String sql = "SELECT usuario, evento, fecha_hora FROM sesion_usuario ORDER BY fecha_hora DESC";

        try (Connection cn = com.nibarra.frontend.util.Db.getConnection(); PreparedStatement ps = cn.prepareStatement(sql); java.sql.ResultSet rs = ps.executeQuery()) {

            dataHistorial.clear();
            int contador = 0;
            while (rs.next()) {
                contador++;
                System.out.println("Fila " + contador + ": " + rs.getString("usuario"));
                dataHistorial.add(new com.nibarra.frontend.model.SesionUsuario(
                        rs.getString("usuario"),
                        rs.getString("evento"),
                        rs.getString("fecha_hora")
                ));
            }

            if (tblHistorial != null) {
                colUsuario.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getUsuario()));
                colEvento.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getEvento()));
                colFecha.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getFecha()));
                tblHistorial.setItems(dataHistorial);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void verIntegrantesEquipo() {
        Equipo equipoSel = tblEquipos.getSelectionModel().getSelectedItem();

        if (equipoSel == null) {
            JOptionPane.showMessageDialog(null, "Selecciona un equipo primero.");
            return;
        }

        EquipoIntegranteDAO dao = new EquipoIntegranteDAO();
        List<EquipoIntegrante> lista = dao.listarPorEquipo(equipoSel.getId());

        StringBuilder sb = new StringBuilder();
        sb.append("Integrantes del equipo ").append(equipoSel.getCodigo()).append(":\n\n");

        if (lista.isEmpty()) {
            sb.append("No hay integrantes registrados.\n");
        } else {
            for (EquipoIntegrante i : lista) {
                sb.append("- ").append(i.getNombre())
                        .append(" (").append(i.getRol()).append(")\n");
            }
        }

        sb.append("\n¿Deseas agregar o eliminar integrantes?");
        int opcion = JOptionPane.showConfirmDialog(null, sb.toString(), "Integrantes", JOptionPane.YES_NO_CANCEL_OPTION);

        if (opcion == JOptionPane.YES_OPTION) {
            String nombre = JOptionPane.showInputDialog("Nombre del nuevo integrante:");
            if (nombre != null && !nombre.isBlank()) {
                EquipoIntegrante nuevo = new EquipoIntegrante();
                nuevo.setIdEquipo(equipoSel.getId());
                nuevo.setNombre(nombre);
                nuevo.setRol("Técnico");
                dao.insertar(nuevo);
                JOptionPane.showMessageDialog(null, "Integrante agregado correctamente.");
            }
        } else if (opcion == JOptionPane.NO_OPTION && !lista.isEmpty()) {
            String nombre = JOptionPane.showInputDialog("Nombre del integrante a eliminar:");
            for (EquipoIntegrante i : lista) {
                if (i.getNombre().equalsIgnoreCase(nombre)) {
                    dao.eliminar(i.getId());
                    JOptionPane.showMessageDialog(null, "Integrante eliminado.");
                    return;
                }
            }
            JOptionPane.showMessageDialog(null, "No se encontró ese nombre.");
        }
    }

}
