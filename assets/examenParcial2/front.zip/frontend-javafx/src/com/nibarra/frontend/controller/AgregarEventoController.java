package com.nibarra.frontend.controller;

import com.nibarra.frontend.util.Db;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class AgregarEventoController {

    @FXML private TextField txtFolio;
    @FXML private ComboBox<String> cbTipo;
    @FXML private ComboBox<String> cbEstado;
    @FXML private DatePicker dpFecha;
    @FXML private TextArea txtDescripcion;

    @FXML
    private void initialize() {
        cbTipo.getItems().setAll("Predictivo","Preventivo","Correctivo");
        cbEstado.getItems().setAll("Por hacer","En revisión","Terminada");
    }

    @FXML
    private void guardarEvento() {
        try (Connection cn = Db.getConnection();
             PreparedStatement ps = cn.prepareStatement(
                 "INSERT INTO orden_servicio(folio, tipo, estado, fecha_programada, descripcion) VALUES (?,?,?,?,?)")) {

            ps.setString(1, txtFolio.getText());
            ps.setString(2, cbTipo.getValue());
            ps.setString(3, cbEstado.getValue());
            ps.setDate(4, java.sql.Date.valueOf(dpFecha.getValue()));
            ps.setString(5, txtDescripcion.getText());

            ps.executeUpdate();
            new Alert(Alert.AlertType.INFORMATION, "Evento agregado correctamente.").showAndWait();

            Stage s = (Stage) txtFolio.getScene().getWindow();
            s.close();

        } catch (Exception e) {
            e.printStackTrace();
            new Alert(Alert.AlertType.ERROR, "Error al guardar el evento.").showAndWait();
        }
    }

    @FXML
    private void cerrarVentana() {
        Stage s = (Stage) txtFolio.getScene().getWindow();
        s.close();
    }
}
