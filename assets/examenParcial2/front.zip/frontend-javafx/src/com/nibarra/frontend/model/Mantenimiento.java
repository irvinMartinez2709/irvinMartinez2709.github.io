package com.nibarra.frontend.model;

import java.time.LocalDate;

public class Mantenimiento {
    private Integer id;
    private String folio;
    private String equipo;
    private String tipoMant;
    private String estado;
    private int avance;
    private LocalDate fechaProgramada;
    private String descripcion;

    public Mantenimiento() {}

    public Mantenimiento(Integer id, String folio, String equipo, String tipoMant, String estado, int avance, LocalDate fechaProgramada, String descripcion) {
        this.id = id;
        this.folio = folio;
        this.equipo = equipo;
        this.tipoMant = tipoMant;
        this.estado = estado;
        this.avance = avance;
        this.fechaProgramada = fechaProgramada;
        this.descripcion = descripcion;
    }

    // Getters y Setters
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public String getFolio() { return folio; }
    public void setFolio(String folio) { this.folio = folio; }
    public String getEquipo() { return equipo; }
    public void setEquipo(String equipo) { this.equipo = equipo; }
    public String getTipoMant() { return tipoMant; }
    public void setTipoMant(String tipoMant) { this.tipoMant = tipoMant; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public int getAvance() { return avance; }
    public void setAvance(int avance) { this.avance = avance; }
    public LocalDate getFechaProgramada() { return fechaProgramada; }
    public void setFechaProgramada(LocalDate fechaProgramada) { this.fechaProgramada = fechaProgramada; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
}
