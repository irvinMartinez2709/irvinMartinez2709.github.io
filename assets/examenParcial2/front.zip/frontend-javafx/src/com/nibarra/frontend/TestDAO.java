package com.nibarra.frontend;

import com.nibarra.frontend.model.Equipo;
import com.nibarra.frontend.service.EquipoDAO;

public class TestDAO {
    public static void main(String[] args) {
        EquipoDAO dao = new EquipoDAO();
        for (Equipo e : dao.listarTodos()) {
            System.out.println(e.getId() + " - " + e.getCodigo() + " - " + e.getTipo());
        }
    }
}
