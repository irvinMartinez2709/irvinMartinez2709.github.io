package com.nibarra.frontend;

import com.nibarra.frontend.util.Db;
import java.sql.Connection;

public class TestConexion {
    public static void main(String[] args) {
        try (Connection cn = Db.getConnection()) {
            System.out.println(":) Conexión exitosa con MySQL");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
