package com.nibarra.frontend.model;

import java.time.LocalDate;

public class EventoCalendario {
    private String folio;
    private String tipo;
    private String estado;
    private LocalDate fecha;

    public EventoCalendario(String folio, String tipo, String estado, LocalDate fecha) {
        this.folio = folio;
        this.tipo = tipo;
        this.estado = estado;
        this.fecha = fecha;
    }

    public String getFolio() { return folio; }
    public String getTipo() { return tipo; }
    public String getEstado() { return estado; }
    public LocalDate getFecha() { return fecha; }

    public void setFolio(String folio) { this.folio = folio; }
    public void setTipo(String tipo) { this.tipo = tipo; }
    public void setEstado(String estado) { this.estado = estado; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }
}
