package com.nibarra.frontend.controller;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class DetalleEventoController {

    @FXML private TextField txtFolio;
    @FXML private TextField txtTipo;
    @FXML private TextField txtEstado;
    @FXML private TextField txtFecha;

    public void setDatos(String folio, String tipo, String estado, String fecha) {
        txtFolio.setText(folio);
        txtTipo.setText(tipo);
        txtEstado.setText(estado);
        txtFecha.setText(fecha);
    }

    @FXML
    private void cerrarVentana() {
        Stage stage = (Stage) txtFolio.getScene().getWindow();
        stage.close();
    }
}
