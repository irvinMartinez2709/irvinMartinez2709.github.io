package com.nibarra.frontend.chat;

import java.time.LocalDateTime;

public class ChatMessage {
    public enum Sender { USER, BOT }
    private final Sender sender;
    private final String text;
    private final LocalDateTime ts;

    public ChatMessage(Sender sender, String text) {
        this.sender = sender;
        this.text = text;
        this.ts = LocalDateTime.now();
    }
    public Sender getSender() { return sender; }
    public String getText() { return text; }
    public LocalDateTime getTs() { return ts; }
}
