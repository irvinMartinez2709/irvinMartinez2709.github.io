package com.nibarra.frontend.controller;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Controller {

    @FXML
    private void irALogin(ActionEvent e) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/nibarra/frontend/view/Login.fxml"));
        Scene loginScene = new Scene(loader.load());
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        stage.setTitle("NIBARRA — Iniciar sesión");
        stage.setScene(loginScene);
        stage.setResizable(false);
        stage.show();
    }
    
    private String enviarMensajeAlBackend(String mensaje) {
    try {
        java.net.URL url = new java.net.URL("http://localhost:8081/api/chat");
        java.net.HttpURLConnection con = (java.net.HttpURLConnection) url.openConnection();
        con.setRequestMethod("POST");
        con.setRequestProperty("Content-Type", "application/json; utf-8");
        con.setRequestProperty("Accept", "application/json");
        con.setDoOutput(true);

        String jsonInputString = "{\"mensaje\": \"" + mensaje + "\"}";

        try (java.io.OutputStream os = con.getOutputStream()) {
            byte[] input = jsonInputString.getBytes("utf-8");
            os.write(input, 0, input.length);
        }

        try (java.io.BufferedReader br = new java.io.BufferedReader(
                new java.io.InputStreamReader(con.getInputStream(), "utf-8"))) {
            StringBuilder response = new StringBuilder();
            String responseLine;
            while ((responseLine = br.readLine()) != null) {
                response.append(responseLine.trim());
            }

            String json = response.toString();
            int start = json.indexOf(":\"") + 2;
            int end = json.lastIndexOf("\"");
            return json.substring(start, end);
        }

    } catch (Exception e) {
        e.printStackTrace();
        return "Error al conectar con el servidor: " + e.getMessage();
    }
}

}
