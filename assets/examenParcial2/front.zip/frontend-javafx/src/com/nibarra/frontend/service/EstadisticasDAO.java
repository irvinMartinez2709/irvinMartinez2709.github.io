package com.nibarra.frontend.service;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import com.nibarra.frontend.util.Db;

public class EstadisticasDAO {

    
    public double obtenerPromedioAvance() {
        String sql = "SELECT AVG(avance) AS promedio FROM orden_servicio";
        try (Connection cn = Db.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return rs.getDouble("promedio") / 100.0;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0.0;
    }

    
    public Map<String, Integer> obtenerConteoPorTipo() {
        Map<String, Integer> mapa = new HashMap<>();
        String sql = "SELECT tipo_mant, COUNT(*) AS total FROM orden_servicio GROUP BY tipo_mant";
        try (Connection cn = Db.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                mapa.put(rs.getString("tipo_mant"), rs.getInt("total"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return mapa;
    }

 
    public Map<String, Integer> obtenerUsoChatbot() {
        Map<String, Integer> datos = new HashMap<>();
        datos.put("mensajes", 150);
        datos.put("preguntas", 90);
        datos.put("respuestas", 60);
        return datos;
    }
}
