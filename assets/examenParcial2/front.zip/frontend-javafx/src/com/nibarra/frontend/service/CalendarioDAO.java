package com.nibarra.frontend.service;

import com.nibarra.frontend.model.EventoCalendario;
import com.nibarra.frontend.util.Db;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


public class CalendarioDAO {

    public List<EventoCalendario> listarPorMes(int anio, int mes) {
        List<EventoCalendario> lista = new ArrayList<>();
        String sql = """
            SELECT folio, tipo_mant, estado, fecha_programada AS fecha
            FROM orden_servicio
            WHERE YEAR(fecha_programada) = ? AND MONTH(fecha_programada) = ?
            ORDER BY fecha_programada
            """;

        try (Connection cn = Db.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setInt(1, anio);
            ps.setInt(2, mes);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                EventoCalendario ev = new EventoCalendario(
                    rs.getString("folio"),
                    rs.getString("tipo_mant"), 
                    rs.getString("estado"),
                    rs.getDate("fecha").toLocalDate()
                );
                lista.add(ev);
            }

        } catch (SQLException e) {
            System.err.println("❌ Error al listar eventos del mes: " + e.getMessage());
        }

        return lista;
    }


    public List<EventoCalendario> listarPorDia(LocalDate fecha) {
        List<EventoCalendario> lista = new ArrayList<>();
        String sql = """
            SELECT folio, tipo_mant, estado, fecha_programada AS fecha
            FROM orden_servicio
            WHERE fecha_programada = ?
            ORDER BY folio
            """;

        try (Connection cn = Db.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setDate(1, Date.valueOf(fecha));

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                EventoCalendario ev = new EventoCalendario(
                    rs.getString("folio"),
                    rs.getString("tipo_mant"), 
                    rs.getString("estado"),
                    rs.getDate("fecha").toLocalDate()
                );
                lista.add(ev);
            }

        } catch (SQLException e) {
            System.err.println("❌ Error al listar eventos del día: " + e.getMessage());
        }

        return lista;
    }

  
    public boolean insertarEvento(EventoCalendario ev) {
        String sql = """
            INSERT INTO orden_servicio(folio, tipo_mant, estado, fecha_programada)
            VALUES (?, ?, ?, ?)
            """;

        try (Connection cn = Db.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setString(1, ev.getFolio());
            ps.setString(2, ev.getTipo()); 
            ps.setString(3, ev.getEstado());
            ps.setDate(4, Date.valueOf(ev.getFecha()));

            int filas = ps.executeUpdate();
            return filas > 0;

        } catch (SQLException e) {
            System.err.println("❌ Error al insertar evento: " + e.getMessage());
            return false;
        }
    }


    public boolean eliminarEvento(String folio) {
        String sql = "DELETE FROM orden_servicio WHERE folio = ?";

        try (Connection cn = Db.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setString(1, folio);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("❌ Error al eliminar evento: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarEstado(String folio, String nuevoEstado) {
        String sql = "UPDATE orden_servicio SET estado = ? WHERE folio = ?";

        try (Connection cn = Db.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setString(1, nuevoEstado);
            ps.setString(2, folio);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("❌ Error al actualizar evento: " + e.getMessage());
            return false;
        }
    }

 
    public ObservableList<EventoCalendario> getObservablePorMes(int anio, int mes) {
        return FXCollections.observableArrayList(listarPorMes(anio, mes));
    }
}
