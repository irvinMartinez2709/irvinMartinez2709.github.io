package com.nibarra.frontend.service;

import com.nibarra.frontend.model.Equipo;
import com.nibarra.frontend.util.Db;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EquipoDAO {

    
    public List<Equipo> listarTodos() {
        List<Equipo> lista = new ArrayList<>();
       String sql = """
SELECT 
    e.*, 
    CASE 
        WHEN EXISTS (
            SELECT 1 FROM orden_servicio os
            WHERE os.id_equipo = e.id 
            AND os.estado IN ('Por hacer', 'En revisión', 'En espera de material')
        ) THEN 0
        ELSE 1
    END AS disponible,
    CASE 
        WHEN EXISTS (
            SELECT 1 FROM orden_servicio os
            WHERE os.id_equipo = e.id 
            AND os.estado IN ('Por hacer', 'En revisión', 'En espera de material')
        ) THEN 1
        ELSE 0
    END AS ocupado
FROM equipo e;
""";



        try (Connection cn = Db.getConnection();
             Statement st = cn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Equipo e = new Equipo();
                e.setId(rs.getInt("id"));
                e.setCodigo(rs.getString("codigo"));
                e.setTipo(rs.getString("tipo"));
                e.setFamilia(rs.getString("familia"));
                e.setTipoDetallado(rs.getString("tipo_detallado"));
                e.setUbicacion(rs.getString("ubicacion"));
                e.setProvincia(rs.getString("provincia"));
                e.setDireccion(rs.getString("direccion"));
                e.setHorarioBase(rs.getString("horario_base"));
                e.setEstado(rs.getString("estado"));
                e.setUsuarioRegistro(rs.getString("usuario_registro"));
                e.setDisponible(rs.getBoolean("disponible"));
                e.setOcupado(rs.getBoolean("ocupado"));
                lista.add(e);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return lista;
    }

 
    public boolean insertar(Equipo e) {
        String sql = """
            INSERT INTO equipo
            (codigo, tipo, familia, tipo_detallado, ubicacion, provincia,
             direccion, horario_base, estado, usuario_registro, disponible, ocupado)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """;

        try (Connection cn = Db.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setString(1, e.getCodigo());
            ps.setString(2, e.getTipo());
            ps.setString(3, e.getFamilia());
            ps.setString(4, e.getTipoDetallado());
            ps.setString(5, e.getUbicacion());
            ps.setString(6, e.getProvincia());
            ps.setString(7, e.getDireccion());
            ps.setString(8, e.getHorarioBase());
            ps.setString(9, e.getEstado());
            ps.setString(10, e.getUsuarioRegistro());
            ps.setBoolean(11, e.isDisponible());
            ps.setBoolean(12, e.isOcupado());

            return ps.executeUpdate() > 0;

        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }


  public boolean actualizar(Equipo e) {
    String sql = """
        UPDATE equipo 
        SET codigo=?, tipo=?, ubicacion=?, estado=?, usuario_registro=?, 
            familia=?, tipo_detallado=?, provincia=?, direccion=?, horario_base=?, 
            disponible=?, ocupado=? 
        WHERE id=?
        """;
    try (Connection cn = Db.getConnection(); 
         PreparedStatement ps = cn.prepareStatement(sql)) {

        ps.setString(1, e.getCodigo());
        ps.setString(2, e.getTipo());
        ps.setString(3, e.getUbicacion());
        ps.setString(4, e.getEstado());
        ps.setString(5, e.getUsuarioRegistro());
        ps.setString(6, e.getFamilia());
        ps.setString(7, e.getTipoDetallado());
        ps.setString(8, e.getProvincia());
        ps.setString(9, e.getDireccion());
        ps.setString(10, e.getHorarioBase());
        ps.setBoolean(11, e.isDisponible());  
        ps.setBoolean(12, e.isOcupado());     
        ps.setInt(13, e.getId());

        return ps.executeUpdate() > 0;
    } catch (SQLException ex) {
        ex.printStackTrace();
        return false;
    }
}



    public boolean eliminar(int id) {
        String sql = "DELETE FROM equipo WHERE id=?";
        try (Connection cn = Db.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
    
    public boolean existeCodigo(String codigo) {
    String sql = "SELECT COUNT(*) FROM equipo WHERE codigo = ?";
    try (Connection cn = Db.getConnection();
         PreparedStatement ps = cn.prepareStatement(sql)) {
        ps.setString(1, codigo);
        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    }
    return false;
}

    
}
