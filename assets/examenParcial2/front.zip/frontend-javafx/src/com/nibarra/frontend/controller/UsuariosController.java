package com.nibarra.frontend.controller;

import com.nibarra.frontend.model.Usuario;
import com.nibarra.frontend.service.UsuarioDAO;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.*;

public class UsuariosController {

    @FXML private TableView<Usuario> tablaUsuarios;
    @FXML private TableColumn<Usuario, Integer> colId;
    @FXML private TableColumn<Usuario, String> colUsername, colPassword, colRol, colActivo;

    @FXML private TextField txtUsername, txtPassword;
    @FXML private ComboBox<String> cmbRol;
    @FXML private CheckBox chkActivo;
    @FXML private Button btnAgregar, btnActualizar, btnEliminar, btnLimpiar;

    private final UsuarioDAO dao = new UsuarioDAO();

    @FXML
    public void initialize() {
        cmbRol.getItems().addAll("admin", "usuario");
        configurarTabla();
        cargarUsuarios();
        asignarEventos();
    }

    private void configurarTabla() {
        colId.setCellValueFactory(c -> new javafx.beans.property.SimpleIntegerProperty(c.getValue().getId()).asObject());
        colUsername.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getUsername()));
        colPassword.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getPasswordHash()));
        colRol.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getRol()));
        colActivo.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().isActivo() ? "Sí" : "No"));
    }

    private void cargarUsuarios() {
        ObservableList<Usuario> lista = FXCollections.observableArrayList(dao.listarTodos());
        tablaUsuarios.setItems(lista);
    }

    private void asignarEventos() {
        tablaUsuarios.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, sel) -> {
            if (sel != null) {
                txtUsername.setText(sel.getUsername());
                txtPassword.setText(sel.getPasswordHash());
                cmbRol.setValue(sel.getRol());
                chkActivo.setSelected(sel.isActivo());
            }
        });

        btnAgregar.setOnAction(e -> agregarUsuario());
        btnActualizar.setOnAction(e -> actualizarUsuario());
        btnEliminar.setOnAction(e -> eliminarUsuario());
        btnLimpiar.setOnAction(e -> limpiarCampos());
    }

    private void agregarUsuario() {
        Usuario u = new Usuario();
        u.setUsername(txtUsername.getText());
        u.setPasswordHash(txtPassword.getText());
        u.setRol(cmbRol.getValue());
        u.setActivo(chkActivo.isSelected());
        dao.insertar(u);
        cargarUsuarios();
        limpiarCampos();
    }

    private void actualizarUsuario() {
        Usuario sel = tablaUsuarios.getSelectionModel().getSelectedItem();
        if (sel == null) return;

        sel.setUsername(txtUsername.getText());
        sel.setPasswordHash(txtPassword.getText());
        sel.setRol(cmbRol.getValue());
        sel.setActivo(chkActivo.isSelected());

        dao.actualizar(sel);
        cargarUsuarios();
        limpiarCampos();
    }

    private void eliminarUsuario() {
        Usuario sel = tablaUsuarios.getSelectionModel().getSelectedItem();
        if (sel != null) {
            dao.eliminar(sel.getId());
            cargarUsuarios();
            limpiarCampos();
        }
    }

    private void limpiarCampos() {
        txtUsername.clear();
        txtPassword.clear();
        cmbRol.setValue(null);
        chkActivo.setSelected(false);
        tablaUsuarios.getSelectionModel().clearSelection();
    }
}
    