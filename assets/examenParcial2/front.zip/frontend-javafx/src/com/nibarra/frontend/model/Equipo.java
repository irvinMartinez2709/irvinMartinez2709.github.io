package com.nibarra.frontend.model;

public class Equipo {
    private int id;
    private String codigo;
    private String tipo;
    private String familia;
    private String tipoDetallado;
    private String ubicacion;
    private String provincia;
    private String direccion;
    private String horarioBase;
    private String estado;
    private String usuarioRegistro;
    private boolean disponible;
    private boolean ocupado;


    public Equipo() {}

    // Constructor completo
    public Equipo(int id, String codigo, String tipo, String familia, String tipoDetallado,
                  String ubicacion, String provincia, String direccion, String horarioBase,
                  String estado, String usuarioRegistro, boolean disponible, boolean ocupado) {
        this.id = id;
        this.codigo = codigo;
        this.tipo = tipo;
        this.familia = familia;
        this.tipoDetallado = tipoDetallado;
        this.ubicacion = ubicacion;
        this.provincia = provincia;
        this.direccion = direccion;
        this.horarioBase = horarioBase;
        this.estado = estado;
        this.usuarioRegistro = usuarioRegistro;
        this.disponible = disponible;
        this.ocupado = ocupado;
    }

    // Getters
    public int getId() { return id; }
    public String getCodigo() { return codigo; }
    public String getTipo() { return tipo; }
    public String getFamilia() { return familia; }
    public String getTipoDetallado() { return tipoDetallado; }
    public String getUbicacion() { return ubicacion; }
    public String getProvincia() { return provincia; }
    public String getDireccion() { return direccion; }
    public String getHorarioBase() { return horarioBase; }
    public String getEstado() { return estado; }
    public String getUsuarioRegistro() { return usuarioRegistro; }
    public boolean isDisponible() { return disponible; }
    public boolean isOcupado() { return ocupado; }

    // Setters
    public void setId(int id) { this.id = id; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
    public void setTipo(String tipo) { this.tipo = tipo; }
    public void setFamilia(String familia) { this.familia = familia; }
    public void setTipoDetallado(String tipoDetallado) { this.tipoDetallado = tipoDetallado; }
    public void setUbicacion(String ubicacion) { this.ubicacion = ubicacion; }
    public void setProvincia(String provincia) { this.provincia = provincia; }
    public void setDireccion(String direccion) { this.direccion = direccion; }
    public void setHorarioBase(String horarioBase) { this.horarioBase = horarioBase; }
    public void setEstado(String estado) { this.estado = estado; }
    public void setUsuarioRegistro(String usuarioRegistro) { this.usuarioRegistro = usuarioRegistro; }
    public void setDisponible(boolean disponible) { this.disponible = disponible; }
    public void setOcupado(boolean ocupado) { this.ocupado = ocupado; }
}
