package com.nibarra.frontend.service;

import com.nibarra.frontend.model.Mantenimiento;
import com.nibarra.frontend.util.Db;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class MantenimientoDAO {

    public List<Mantenimiento> listarTodos() {
        String sql = """
            SELECT os.id, os.folio, e.codigo AS equipo, os.tipo_mant, os.estado, os.avance, os.fecha_programada, os.descripcion
            FROM orden_servicio os
            JOIN equipo e ON os.id_equipo = e.id
            ORDER BY os.fecha_programada DESC
            """;
        List<Mantenimiento> lista = new ArrayList<>();
        try (Connection cn = Db.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(new Mantenimiento(
                    rs.getInt("id"),
                    rs.getString("folio"),
                    rs.getString("equipo"),
                    rs.getString("tipo_mant"),
                    rs.getString("estado"),
                    rs.getInt("avance"),
                    rs.getDate("fecha_programada").toLocalDate(),
                    rs.getString("descripcion")
                ));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return lista;
    }

public boolean insertar(Mantenimiento m, int idEquipo) {
    String sql = "INSERT INTO orden_servicio (folio, id_equipo, tipo_mant, estado, avance, fecha_programada, descripcion) VALUES (?,?,?,?,?,?,?)";
    try (Connection cn = Db.getConnection();
         PreparedStatement ps = cn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
        ps.setString(1, m.getFolio());
        ps.setInt(2, idEquipo);
        ps.setString(3, m.getTipoMant());
        ps.setString(4, m.getEstado());
        ps.setInt(5, m.getAvance());
        ps.setDate(6, Date.valueOf(m.getFechaProgramada()));
        ps.setString(7, m.getDescripcion());
        
        int rows = ps.executeUpdate();
        return rows > 0;
    } catch (SQLException ex) {
        ex.printStackTrace();
        return false;
    }
}

    public boolean actualizar(Mantenimiento m, int idEquipo) {
        String sql = "UPDATE orden_servicio SET id_equipo=?, tipo_mant=?, estado=?, avance=?, fecha_programada=?, descripcion=? WHERE folio=?";
        try (Connection cn = Db.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, idEquipo);
            ps.setString(2, m.getTipoMant());
            ps.setString(3, m.getEstado());
            ps.setInt(4, m.getAvance());
            ps.setDate(5, Date.valueOf(m.getFechaProgramada()));
            ps.setString(6, m.getDescripcion());
            ps.setString(7, m.getFolio());
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    public boolean eliminar(String folio) {
        String sql = "DELETE FROM orden_servicio WHERE folio=?";
        try (Connection cn = Db.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, folio);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
}
