package com.nibarra.frontend.controller;

import com.nibarra.frontend.util.Db;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.sql.*;
import java.time.LocalDate;

public class EquiposReparacionController {

    @FXML private TextField txtFolio, txtEquipo, txtDescripcion, txtCostoEstimado, txtCostoFinal;
    @FXML private DatePicker dpFechaInicio;
    @FXML private ComboBox<String> cbEstado;
    @FXML private TableView<Reparacion> tblReparaciones;
    @FXML private TableColumn<Reparacion, Integer> colId;
    @FXML private TableColumn<Reparacion, String> colFolio, colEquipo, colDescripcion, colEstado;
    @FXML private TableColumn<Reparacion, Double> colCostoEst, colCostoFin;

    private final ObservableList<Reparacion> lista = FXCollections.observableArrayList();

    @FXML
    private void initialize() {
        
        cbEstado.setItems(FXCollections.observableArrayList(
                "En reparación", "Esperando repuesto", "Completada"
        ));
        colId.setCellValueFactory(d -> new javafx.beans.property.SimpleIntegerProperty(d.getValue().getId()).asObject());
        colFolio.setCellValueFactory(d -> new javafx.beans.property.SimpleStringProperty(d.getValue().getFolio()));
        colEquipo.setCellValueFactory(d -> new javafx.beans.property.SimpleStringProperty(d.getValue().getEquipo()));
        colDescripcion.setCellValueFactory(d -> new javafx.beans.property.SimpleStringProperty(d.getValue().getDescripcion()));
        colCostoEst.setCellValueFactory(d -> new javafx.beans.property.SimpleDoubleProperty(d.getValue().getCostoEstimado()).asObject());
        colCostoFin.setCellValueFactory(d -> new javafx.beans.property.SimpleDoubleProperty(d.getValue().getCostoFinal()).asObject());
        colEstado.setCellValueFactory(d -> new javafx.beans.property.SimpleStringProperty(d.getValue().getEstado()));

        tblReparaciones.setItems(lista);
        cargarReparaciones();
    }

    @FXML
    private void cargarReparaciones() {
        lista.clear();
        String sql = "SELECT r.id, r.folio, e.codigo AS equipo, r.descripcion, r.costo_estimado, r.costo_final, r.estado " +
                     "FROM equipo_reparacion r JOIN equipo e ON r.id_equipo = e.id";
        try (Connection cn = Db.getConnection(); Statement st = cn.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                lista.add(new Reparacion(
                        rs.getInt("id"),
                        rs.getString("folio"),
                        rs.getString("equipo"),
                        rs.getString("descripcion"),
                        rs.getDouble("costo_estimado"),
                        rs.getDouble("costo_final"),
                        rs.getString("estado")
                ));
            }
        } catch (Exception e) {
            mostrar("Error al cargar: " + e.getMessage());
        }
    }

    @FXML
    private void agregarReparacion() {
        try {
            String folio = txtFolio.getText().trim();
            String equipoCod = txtEquipo.getText().trim();
            String desc = txtDescripcion.getText().trim();
            LocalDate fecha = dpFechaInicio.getValue();
            double costoEst = Double.parseDouble(txtCostoEstimado.getText());
            double costoFin = Double.parseDouble(txtCostoFinal.getText());
            String estado = cbEstado.getValue();

            if (costoEst > 1500) {
                mostrar("⚠️ Costo estimado supera el límite (1500 USD)");
                return;
            }
            if (costoFin > 2000) {
                mostrar("⚠️ Costo final supera el tope permitido (2000 USD)");
                return;
            }

            int idEquipo = obtenerIdEquipo(equipoCod);
            if (idEquipo == -1) {
                mostrar("Equipo no encontrado: " + equipoCod);
                return;
            }

            String sql = "INSERT INTO equipo_reparacion (folio, id_equipo, descripcion, fecha_inicio, costo_estimado, costo_final, estado) "
                       + "VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (Connection cn = Db.getConnection(); PreparedStatement ps = cn.prepareStatement(sql)) {
                ps.setString(1, folio);
                ps.setInt(2, idEquipo);
                ps.setString(3, desc);
                ps.setDate(4, java.sql.Date.valueOf(fecha));
                ps.setDouble(5, costoEst);
                ps.setDouble(6, costoFin);
                ps.setString(7, estado);
                ps.executeUpdate();
            }

            mostrar("Reparación registrada correctamente.");
            cargarReparaciones();
        } catch (Exception e) {
            mostrar("Error al agregar: " + e.getMessage());
        }
    }

    private int obtenerIdEquipo(String codigo) {
        try (Connection cn = Db.getConnection();
             PreparedStatement ps = cn.prepareStatement("SELECT id FROM equipo WHERE codigo=?")) {
            ps.setString(1, codigo);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt("id");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1;
    }

    @FXML
    private void actualizarReparacion() {
        Reparacion sel = tblReparaciones.getSelectionModel().getSelectedItem();
        if (sel == null) {
            mostrar("Selecciona una reparación para actualizar.");
            return;
        }

        try (Connection cn = Db.getConnection();
             PreparedStatement ps = cn.prepareStatement(
                     "UPDATE equipo_reparacion SET descripcion=?, costo_estimado=?, costo_final=?, estado=? WHERE id=?")) {
            ps.setString(1, txtDescripcion.getText());
            ps.setDouble(2, Double.parseDouble(txtCostoEstimado.getText()));
            ps.setDouble(3, Double.parseDouble(txtCostoFinal.getText()));
            ps.setString(4, cbEstado.getValue());
            ps.setInt(5, sel.getId());
            ps.executeUpdate();
            mostrar("Reparación actualizada correctamente.");
            cargarReparaciones();
        } catch (Exception e) {
            mostrar("Error al actualizar: " + e.getMessage());
        }
    }

    @FXML
    private void eliminarReparacion() {
        Reparacion sel = tblReparaciones.getSelectionModel().getSelectedItem();
        if (sel == null) {
            mostrar("Selecciona una reparación para eliminar.");
            return;
        }
        try (Connection cn = Db.getConnection();
             PreparedStatement ps = cn.prepareStatement("DELETE FROM equipo_reparacion WHERE id=?")) {
            ps.setInt(1, sel.getId());
            ps.executeUpdate();
            mostrar("Reparación eliminada correctamente.");
            cargarReparaciones();
        } catch (Exception e) {
            mostrar("Error al eliminar: " + e.getMessage());
        }
    }
     @FXML
    private void limpiarCampos() {
    txtFolio.clear();
    txtEquipo.clear();
    txtDescripcion.clear();
    txtCostoEstimado.clear();
    txtCostoFinal.clear();
}

    private void mostrar(String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION, msg, ButtonType.OK);
        a.setHeaderText(null);
        a.showAndWait();
    }

    // Clase interna para el modelo
    public static class Reparacion {
        private final int id;
        private final String folio, equipo, descripcion, estado;
        private final double costoEstimado, costoFinal;

        public Reparacion(int id, String folio, String equipo, String descripcion, double costoEstimado, double costoFinal, String estado) {
            this.id = id;
            this.folio = folio;
            this.equipo = equipo;
            this.descripcion = descripcion;
            this.costoEstimado = costoEstimado;
            this.costoFinal = costoFinal;
            this.estado = estado;
        }
        public int getId() { return id; }
        public String getFolio() { return folio; }
        public String getEquipo() { return equipo; }
        public String getDescripcion() { return descripcion; }
        public double getCostoEstimado() { return costoEstimado; }
        public double getCostoFinal() { return costoFinal; }
        public String getEstado() { return estado; }
    }


}
