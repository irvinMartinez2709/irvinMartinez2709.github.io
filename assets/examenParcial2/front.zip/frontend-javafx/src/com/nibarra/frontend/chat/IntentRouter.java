 package com.nibarra.frontend.chat;

import java.util.Locale;
import java.util.regex.Pattern;

public class IntentRouter {

    public enum Intent {
        SALUDO, AYUDA, LISTAR_USUARIOS, LISTAR_TECNICOS,
        PROXIMO_MANTENIMIENTO, ESTADO_FOLIO, PENDIENTES,
        HORARIO_TECNICO, FILTRO_FECHAS, NINGUNA
    }

    private static final Pattern P_SALUDO = Pattern.compile("\\b(hola|buen[oa]s|saludo)\\b", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern P_USUARIOS = Pattern.compile("\\b(usuarios|lista de usuarios|quienes tienen cuenta)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern P_TECNICOS = Pattern.compile("\\b(t[eé]cnicos|equipo t[eé]cnico|personal de mantenimiento)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern P_PROX = Pattern.compile("\\b(prox|pr[oó]ximo mantenimiento|qu[eé] sigue|siguiente mantenimiento)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern P_FOLIO = Pattern.compile("\\b(folio\\s*[-#: ]?\\d+|estado del folio|seguimiento del folio)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern P_PEND = Pattern.compile("\\b(pendientes|por hacer|no terminad[oa]s)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern P_HORARIO = Pattern.compile("\\b(horario|turno)\\b.*\\b(t[eé]cnico|tecnico)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern P_AYUDA = Pattern.compile("\\b(ayuda|que puedes hacer|comandos)\\b", Pattern.CASE_INSENSITIVE);

    public Intent route(String text) {
        if (text == null || text.isBlank()) return Intent.NINGUNA;
        String t = text.toLowerCase(Locale.ROOT);

        if (P_AYUDA.matcher(t).find()) return Intent.AYUDA;
        if (P_SALUDO.matcher(t).find()) return Intent.SALUDO;
        if (P_USUARIOS.matcher(t).find()) return Intent.LISTAR_USUARIOS;
        if (P_TECNICOS.matcher(t).find()) return Intent.LISTAR_TECNICOS;
        if (P_PROX.matcher(t).find()) return Intent.PROXIMO_MANTENIMIENTO;
        if (P_FOLIO.matcher(t).find()) return Intent.ESTADO_FOLIO;
        if (P_PEND.matcher(t).find()) return Intent.PENDIENTES;
        if (P_HORARIO.matcher(t).find()) return Intent.HORARIO_TECNICO;

        return Intent.NINGUNA;
    }
}
