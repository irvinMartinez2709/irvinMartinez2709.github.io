package com.nibarra.frontend.service;

import com.nibarra.frontend.model.EquipoIntegrante;
import com.nibarra.frontend.util.Db;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class EquipoIntegranteDAO {


    public List<EquipoIntegrante> listarPorEquipo(int idEquipo) {
        List<EquipoIntegrante> lista = new ArrayList<>();
        String sql = "SELECT * FROM equipo_integrante WHERE id_equipo = ?";

        try (Connection cn = Db.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setInt(1, idEquipo);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                EquipoIntegrante i = new EquipoIntegrante();
                i.setId(rs.getInt("id"));
                i.setIdEquipo(rs.getInt("id_equipo"));
                i.setNombre(rs.getString("nombre"));
                i.setRol(rs.getString("rol"));
                i.setTelefono(rs.getString("telefono"));
                i.setCorreo(rs.getString("correo"));
                lista.add(i);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return lista;
    }

    // Insertar nuevo integrante
    public boolean insertar(EquipoIntegrante i) {
        String sql = "INSERT INTO equipo_integrante (id_equipo, nombre, rol, telefono, correo) VALUES (?, ?, ?, ?, ?)";

        try (Connection cn = Db.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setInt(1, i.getIdEquipo());
            ps.setString(2, i.getNombre());
            ps.setString(3, i.getRol());
            ps.setString(4, i.getTelefono());
            ps.setString(5, i.getCorreo());

            return ps.executeUpdate() > 0;

        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    // Eliminar integrante
    public boolean eliminar(int id) {
        String sql = "DELETE FROM equipo_integrante WHERE id=?";
        try (Connection cn = Db.getConnection();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
}
