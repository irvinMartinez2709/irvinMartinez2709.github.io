package com.nibarra.frontend.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import com.nibarra.frontend.App;
import com.nibarra.frontend.util.Db;

public class LoginController {

    @FXML
    private TextField txtUsuario;
    @FXML
    private PasswordField txtContrasena;
    @FXML
    private Button btnEntrar;
    @FXML
    private Button btnVolver;
    @FXML
    private Label lblEstado;

    @FXML
    private void iniciarSesion(ActionEvent e) throws IOException {
        String usuario = txtUsuario.getText().trim();
        String password = txtContrasena.getText().trim();

        if (usuario.isEmpty() || password.isEmpty()) {
            lblEstado.setText("Debes ingresar usuario y contraseña.");
            return;
        }

        try (Connection conn = Db.getConnection()) {
            String sql = "SELECT id, password_hash, rol FROM usuario WHERE username=? AND activo=1";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, usuario);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String passBD = rs.getString("password_hash");
                if (password.equals(passBD)) {
                    int idUsuario = rs.getInt("id");
                    String usernameBD = usuario;

         
                    com.nibarra.frontend.util.UsuarioSesion.iniciarSesion(idUsuario, usernameBD);


                    PreparedStatement ps2 = conn.prepareStatement(
                            "INSERT INTO sesion_usuario (usuario, evento) VALUES (?, 'LOGIN')");
                    ps2.setString(1, txtUsuario.getText());
                    ps2.executeUpdate();

                    
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/nibarra/frontend/view/Dashboard.fxml"));
                    Scene dashboardScene = new Scene(loader.load());
                    Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
                    stage.setTitle("Panel Principal — NIBARRA");
                    stage.setScene(dashboardScene);
                    stage.show();

                } else {
                    lblEstado.setText("Contraseña incorrecta.");
                }
            } else {
                lblEstado.setText("Usuario no encontrado o inactivo.");
            }
        } catch (SQLException ex) {
            lblEstado.setText("Error al conectar con la base de datos.");
            ex.printStackTrace();
        }
    }

    @FXML
    private void volverAInicio(ActionEvent e) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/nibarra/frontend/MainApp.fxml"));
        Scene portada = new Scene(loader.load());
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        stage.setTitle("NIBARRA — Portada");
        stage.setScene(portada);
        stage.setResizable(false);
        stage.show();
    }
        @FXML
private void limpiarLogin(ActionEvent event) {
    if (txtUsuario != null) {
        txtUsuario.clear();
    }
    if (txtContrasena != null) {
        txtContrasena.clear();
    }
    System.out.println("Campos de login limpiados correctamente.");
}
}
