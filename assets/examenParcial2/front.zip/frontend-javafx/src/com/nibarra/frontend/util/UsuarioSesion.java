package com.nibarra.frontend.util;

public class UsuarioSesion {

    private static int idActual;
    private static String nombreUsuario;
    private static String rol;

  
    public static void iniciarSesion(int id, String nombre) {
        idActual = id;
        nombreUsuario = nombre;
    }

    public static int getIdActual() {
        return idActual;
    }

    public static String getNombreUsuario() {
        return nombreUsuario;
    }

    public static String getRol() {
        return rol;
    }

    public static void setRol(String r) {
        rol = r;
    }

    public static void cerrarSesion() {
        idActual = 0;
        nombreUsuario = null;
        rol = null;
    }
}
