module com.nibarra.backendchatbot {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.nibarra.backendchatbot to javafx.fxml;
    exports com.nibarra.backendchatbot;
}